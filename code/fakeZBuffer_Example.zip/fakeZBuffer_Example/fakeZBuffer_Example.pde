PShader fakeZBufferShader;
int numSpheres;
float[] parameters;
PShape shape;

void setup() {
  size(800,800,P3D);
  smooth(8);
  noCursor();
 
  numSpheres=2000;
  
  parameters=new float[4*numSpheres];
  for (int i=0; i<4*numSpheres; i+=4) {
    parameters[i]=random(0.12, 6.0);
    
    float elevation = asin(random(-1.0, 1.0));
    float azimuth = random(TWO_PI);
    float r = 200.0 * pow(random(1.0), 1.0 / 3.0);
    if (random(100)<10) {
      r*=1.2;
      parameters[i]/=2.0;
    }
    parameters[i+1]=r * cos(elevation) *cos(azimuth);
    parameters[i+2]=r * cos(elevation) * sin(azimuth);
    parameters[i+3]=r * sin(elevation);
  }
  
  fakeZBufferShader = loadShader("fakeZBufferfrag.glsl", "fakeZBuffervert.glsl");
  fakeZBufferShader.set("color1", 1.0, 1.0, 1.0, 1.0);
  fakeZBufferShader.set("color2", 0.0, 0.0, 0.0, 1.0);
  fakeZBufferShader.set("frequency", 10.0); 
  fakeZBufferShader.set("near",0.21*height/tan(radians(30)));  
  fakeZBufferShader.set("far", 0.66*height/tan(radians(30))); 
  
  noStroke();
  fill(255); 
  shape=createShape(SPHERE, 5.0);
}

void draw() {
  background(0);
  translate(width/2, height/2);
  rotateY(map(mouseX, 0, width, -PI, PI)+radians(0.05*frameCount));
  rotateX(map(mouseY, 0, height, PI, -PI));
  fakeZBufferShader.set("phase", 2.0*radians(frameCount));
  shader(fakeZBufferShader);
  for (int i=0; i<4*numSpheres; i+=4) {
    pushMatrix();
    translate(parameters[i+1], parameters[i+2], parameters[i+3]);
    scale(parameters[i]);
    shape(shape);
    popMatrix();
  }
}
