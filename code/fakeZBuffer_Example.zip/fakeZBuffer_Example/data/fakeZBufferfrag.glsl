#define PROCESSING_COLOR_SHADER
 
uniform float near;
uniform float far;
uniform vec4 color1;
uniform vec4 color2;
uniform float phase=0;
uniform float frequency=10.0;
void main(void){ 
 float depth = gl_FragCoord.z / gl_FragCoord.w; 
 float f=phase+frequency*3.1415926535*smoothstep(near,far,depth);
 gl_FragColor = mix(color1,color2,0.5+0.5*cos(f));
}




