
uniform mat4 transformMatrix;

attribute vec4 position;

void main() {
  gl_Position = transformMatrix * position;
}