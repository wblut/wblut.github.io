WrappedLorenCA ca;
long seed;

void setup() {
  size(1024, 1024);
  // 3^25 possible rulesets, 847.288.609.443
  ca=new WrappedLorenCA(256, seed=(long)(Math.random()*847288609443L));
}

void draw() {
  background(255);
  ca.update();
  ca.draw(4);
}


//Press spacebar to save image with the seed as its name
void keyPressed() {
  if(key==' '){
  save(String.format("%012d", seed)+".png"); 
  ca=new WrappedLorenCA(256, seed=(long)(Math.random()*847288609443L));
  loop();
  }else{
    ca=new WrappedLorenCA(256, seed=(long)(Math.random()*847288609443L));
  loop();
  }
}

class WrappedLorenCA {
  int N;
  boolean[][] values;
  boolean[][] buffer;

  int[][] rules;
  int[][] age;

  WrappedLorenCA(int N, long index) {
    N=max(N, 1);
    this.N=N;
    this.values=new boolean[N][N];
    this.buffer=new boolean[N][N];
    this.age=new int[N][N];
    this.rules=new int[5][5];
    //The 25 entries of the ruleset are described by the seed in ternary notation
     println(seed);
    for (int i=0; i<5; i++) {
      for (int j=0; j<5; j++) {
        this.rules[i][j]=(int)(index%3);
        index/=3;
        print(this.rules[i][j]);
        if(j<4) print(", ");
      }
      println();
    }
   
    init();
  }

  void init() {
    
    noiseSeed((int)random(10000000));
    for (int i=0; i<N; i++) {
      for (int j=0; j<N; j++) {
        values[i][j]=noise(0.035*i, 0.035*j)<0.5;//random(100)<50;
        age[i][j]=0;
      }
    }
  }

  int getN() {
    return N;
  }

  boolean update() {
    int row, col, rule;
    for (int i=0; i<N; i++) {
      for (int j=0; j<N; j++) {
        //CARDINAL NEIGHBORS
        row=0;
        if ( getValue(i, j-1)) row++;
        if (getValue(i, j+1)) row++;
        if (getValue(i-1, j)) row++;
        if (getValue(i+1, j)) row++;
        
        //DIAGONAL NEIGHBORS
        col=0;
        if (getValue(i-1, j-1)) col++;
        if (getValue(i-1, j+1)) col++;
        if (getValue(i+1, j+1)) col++;
        if (getValue(i+1, j-1)) col++;

        rule=rules[row][col];
        /*
        0: SWITCH OFF
        1: SWITCH ON
        2: UNCHANGED
        */
        setBufferValue(i, j, rule==0?false:rule==1?true:getValue(i, j));
      }
    }

    bufferToValues();
    return true;
  }

  boolean getValue(int i, int j) {
    while (i<0) i+=N;
    while (j<0) j+=N;
    return values[i%N][j%N];
  }

  void setValue(int i, int j, boolean value) {
    while (i<0) i+=N;
    while (j<0) j+=N;
    values[i%N][j%N]=value;
  }

  boolean getBufferValue(int i, int j) {
    while (i<0) i+=N;
    while (j<0) j+=N;
    return buffer[i%N][j%N];
  }

  void setBufferValue(int i, int j, boolean value) {
    while (i<0) i+=N;
    while (j<0) j+=N;
    buffer[i%N][j%N]=value;
  }

  boolean bufferToValues() { 
    boolean changed=false;
    for (int i=0; i<N; i++) {
      for (int j=0; j<N; j++) {
        if (buffer[i][j]!=values[i][j]) {
          changed=true;
          age[i][j]=0;
        } else {
          age[i][j]++;
        }
        values[i][j]=buffer[i][j];
      }
    }

    return changed;
  }

  void draw(int L) {
    pushStyle();
    noStroke(); 
    for (int i=0; i<N; i++) {
      for (int j=0; j<N; j++) {
        fill(getValue(i, j)?max(0, 255-age[i][j]*10):255);
        rect(i*L, j*L, L, L);
      }
    }
    popStyle();
  }
}
