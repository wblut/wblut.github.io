float ax, ay;
PImage sprite;
int numPoints;
float[][] points;


void setup() {
  fullScreen(P3D);
  smooth(8);
  imageMode(CENTER);
  createSprite();
  createPoints();
}

void createSprite(){
 int maxSpriteSize=256;
 int minSpriteSize=8;
 float glowKernelWidth=3f;// glow core size parameter
 float glowKernelDecayPower=2.0f;// glow core decay power (~1.4-3.6)
 int reqGlowKernelSize =constrain(5*(int)pow(100f*glowKernelWidth, 1f/glowKernelDecayPower),minSpriteSize,maxSpriteSize);// required image size to accomodate the glow kernel
 int half=reqGlowKernelSize/2;
 reqGlowKernelSize=2*half;
 sprite=createImage(reqGlowKernelSize, reqGlowKernelSize, RGB);
 float r2, brightness;
  for (int i=0; i <  reqGlowKernelSize; i++) {
    for (int j=0; j <  reqGlowKernelSize; j++) {
     r2=(i-half)*(i-half)+(j-half)*(j-half);
     brightness=255.999999f*glowKernelWidth/(glowKernelWidth+pow(r2, 0.5*glowKernelDecayPower));// radial symmetric decreasing function
     sprite.pixels[i+reqGlowKernelSize*j] = color(brightness, brightness);
    }
  }
}

void createPoints() {
  numPoints=1000;
  points=new float[numPoints][];
  for(int i=0;i<numPoints;i++){
   points[i]=new float[]{random(-300,300), random(-300,300),random(-300,300)};
  }
}


void draw() {
  background(0);
  translate(width/2,height/2);
  rotateY(ay=map(mouseX,0,width,-PI,PI));
  rotateX(ax=map(mouseY,height,0,-PI,PI));

  hint(ENABLE_DEPTH_MASK);
  blendMode(BLEND);
  //draw normally
  
  hint(DISABLE_DEPTH_MASK);
  blendMode(ADD);
  //draw additive

  for(int i=0;i<numPoints;i++){
    //For each point: locally undo rotation so the sprite is always facing the camera
    pushMatrix();
    translate(points[i][0], points[i][1], points[i][2]); 
    rotateX(-ax);
    rotateY(-ay);
    scale(1.2+0.8*cos(radians(i+frameCount)));
    image(sprite, 0, 0);
    popMatrix();
  }
}
