FastNoiseLite FNL;

color[] palette;

Orbit[] orbits;
int numOrbits;
int numPointsPerOrbit;
float minimumSeparation;
float noiseAmplitude;

float noiseRadius;
float noiseCenterX;
float noiseCenterY;
float orbitModulationAngleRange;
float orbitModulationAngleOffsetFactor;
float maximumOrbitModulationStrength;
float globalAngleOffset;


void setup() {
  fullScreen(P3D);
  smooth(16);

  create();
}



void create() {
  int seed =(int)random(100000000);
  randomSeed(seed);
  
  //better noiwe than Processing's default
  FNL=new FastNoiseLite(seed);

  palette=getPalette();
  numOrbits=400;
  numPointsPerOrbit=2000;
  minimumSeparation=random(100)<10?0:random(0, 10);
  noiseAmplitude=random(10, 100);
  noiseRadius=random(0.5, 10.0);
  noiseCenterX=random(-256, 256);
  noiseCenterY=random(-256, 256);


  orbits=new Orbit[numOrbits];
  orbitModulationAngleRange=(int)random(2, 64);
  orbitModulationAngleOffsetFactor=random(TWO_PI);
  maximumOrbitModulationStrength=random(10, 100);
  globalAngleOffset=random(TWO_PI);

  float[] previousRadius= new float[numPointsPerOrbit];
  float orbitModulationAngle;
  float orbitModulationAngleOffset;
  float orbitModulationStrength;
  for (int orbit=0; orbit<numOrbits; orbit++) {
    orbitModulationAngle=(int)map(orbit, 0, numOrbits-1, 0, orbitModulationAngleRange)*TWO_PI;
    orbitModulationAngleOffset=orbit*orbitModulationAngleOffsetFactor;
    orbitModulationStrength=map(orbit, 0, numOrbits-1, 0, maximumOrbitModulationStrength);

    float[] radius = new float[numPointsPerOrbit];
    for (int point=0; point<numPointsPerOrbit; point++) {
      radius[point]=previousRadius[point]+noiseAmplitude*circularNoise(point, noiseRadius*orbit, noiseRadius*orbit);
      radius[point]+= orbitModulationStrength*sin(orbitModulationAngleOffset+map(point, 0, numPointsPerOrbit-1, 0, orbitModulationAngle));
    }
    orbits[orbit]=new Orbit(radius);
    if (orbit>0) {
      orbits[orbit].separateOrbitFrom(orbits[orbit-1], minimumSeparation);
    } else {
      orbits[orbit].separateOrbit(minimumSeparation);
    }
    previousRadius=radius;
  }
}



void draw() {
  background(palette[3]);
  translate(width/2, height/2);

  stroke(0);
  fill(palette[0]);
  for (int orbit=numOrbits-1; orbit>-1; orbit--) {
    fill((orbit%2)==0?palette[3]:palette[(orbit/2+1)%3]);
    orbits[orbit].draw();
  }
  translate(0, 0, 2);
  noStroke();
  fill(palette[3]);
  rect(-width/2, -height/2, width, 100);
  rect(-width/2, height/2-100, width, 100);
  rect(-width/2, -height/2, 100, height);
  rect(width/2-100, -height/2, 100, height);
}

float circularNoise(int i, float radius, float z) {

  float angle=map(i, 0, numPointsPerOrbit-1, 0, TWO_PI)+globalAngleOffset;
  return 0.5*(1.0+FNL.GetNoise(radius*cos(angle)+noiseCenterX, radius*sin(angle)+noiseCenterY, z));
}






class Orbit {
  int num;
  float[] radius;

  Orbit(float[] radius) {
    num=radius.length;
    this.radius=radius;
  }

  void smooth() {
    float[] buffer= new float[num];
    for (int i=0; i<num; i++) {
      buffer[i]=(radius[i]+radius[(i+1)%num]+radius[(i+num-1)%num])/3.0;
    }
    radius=buffer;
  }

  void separateOrbitFrom(Orbit C, float minimumSeparation) {
    float currentMinimumSeparation=100000;
    for (int i=0; i<num; i++) {
      currentMinimumSeparation=min(currentMinimumSeparation, radius[i]- C.radius[i]);
    }
    for (int i=0; i<num; i++) {
      radius[i]=radius[i]-currentMinimumSeparation+minimumSeparation;
    }
  }

  void separateOrbit(float minimumSeparation) {
    float currentMinimumSeparation=100000;
    for (int i=0; i<num; i++) {
      currentMinimumSeparation=min(currentMinimumSeparation, radius[i]);
    }
    for (int i=0; i<num; i++) {
      radius[i]=radius[i]-currentMinimumSeparation+minimumSeparation;
    }
  }

  void draw() {
    float angle;
    beginShape();
    for (int i=0; i<num; i++) {
      angle=map(i, 0, num-1, 0, TWO_PI);
      vertex(cos(angle)*radius[i], sin(angle)*radius[i]);
    }
    endShape();
  }
}



color[] getPalette() {
  float lineAlpha = 255;
  color[][] palettes = new color[][]
    {
    {color(255), color(0), color(180), color(80), color(0, lineAlpha)}
  };

  int paletteRoll = (int)(random(palettes.length));
  int tmp;
  int[] index =new int[] {0, 1, 2, 3};
  for (int i = 3; i > 0; i--) {
    int j = (int)random(i);
    tmp = index[i];
    index[i] = index[j];
    index[j] = tmp;
  }

  color[] pal=new color[5];
  for (int i=0; i<4; i++) {
    pal[i]=palettes[paletteRoll][index[i]];
  }
  pal[4]=palettes[paletteRoll][4];
  return pal;
}

void mousePressed() {
  create();
}
