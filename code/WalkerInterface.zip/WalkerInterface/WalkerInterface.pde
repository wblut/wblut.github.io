ArrayList<Walker> walkers;
ArrayList<Path> paths;
void setup() {
  size(800, 800, P3D);
  smooth(16);
  walkers=new ArrayList<Walker>();
  paths=new ArrayList<Path>();
  Path path;
  for (int i=0; i<100; i++) {
    path=new LineSegment(new PVector(random(width), random(height)), new PVector(random(width), random(height)));

    paths.add(path);
    walkers.add(new Walker(path, random(0.002, 0.01)));
  }
}


void draw() {
  background(255);
  for (Walker walker : walkers) {
    walker.draw();
  }
  update();
}

void update() {
  for (Walker walker : walkers) {
    walker.update();
  }
}


interface Path {
  PVector getPointOnPath(float f); // f: [0,1]
}


class Walker {
  PVector position;
  Path path;
  float currentF;
  float stepF;

  Walker(Path path, float step) {
    this.path=path;
    stepF=step;
    currentF=0.0;
    position=path.getPointOnPath(currentF);
  }

  void update() {
    currentF+=stepF;
    if (currentF<0.0) { 
      currentF+=1.0;
    } else if (currentF>1.0) { 
      currentF-=1.0;
    }
    position.set(path.getPointOnPath(currentF));
  }

  void draw() {
    ellipse(position.x, position.y, 4, 4);
  }
}

class LineSegment implements Path {
  PVector start;
  PVector end;

  LineSegment(PVector start, PVector end) {
    this.start=start;
    this.end=end;
  }

  PVector getPointOnPath(float f) {
    return PVector.lerp(end, start, f);
  }
}
