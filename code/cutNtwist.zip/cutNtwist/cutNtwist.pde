import java.util.*;
ArrayList meshes;

float bufferMouseX, bufferMouseY;

boolean ROTATING;
boolean SLIDING;
int COUNTER;
Plane P=new Plane(new PVector(),new PVector(random(-1,1),random(-1,1),random(-1,1)));
PVector d=new PVector();
float f;
float da;
void setup(){
  size(800,800,P3D);
  background(255);
  

ROTATING=false;
SLIDING=false;
COUNTER=0;
 P=new Plane(new PVector(0,random(-200,200),0),new PVector(random(-1,1),10,random(-1,1)));
d=P.n.cross(new PVector(random(-1,1),random(-1,1),random(-1,1)));
      d.normalize();
      
  buildMeshes();
  f=0;
  da=0;
}

void draw(){
  lights();  
  background(255);
  translate(width/2,height/2,0);  
  bufferMouseX=0.95f*bufferMouseX+0.05f*mouseX;
  bufferMouseY=0.95f*bufferMouseY+0.05f*mouseY;
  rotateY(bufferMouseX/(float)width*TWO_PI);
  rotateX(bufferMouseY/(float)height*TWO_PI);
    if(f>0f){
   f=max(0f,f*0.95f); 
   if(f<0.05f) f=0f;
  }
  for(int i=0;i<meshes.size();i++){
    pushMatrix();
    HE_Mesh mesh=(HE_Mesh)meshes.get(i);
    mesh.setBodyCenter();
    translate(mesh.bodyCenter.x*f,mesh.bodyCenter.y*f,mesh.bodyCenter.z*f);
    noStroke();
    fill(255);
    mesh.draw(); 
    stroke(0,100);
    noFill();
    strokeWeight(2);
    mesh.drawEdges(true);
   popMatrix();

  }
if(ROTATING){
for(int i=0;i<meshes.size();i++){
      HE_Mesh mesh=(HE_Mesh)meshes.get(i);
      mesh.setBodyCenter();      
      if(P.side(mesh.bodyCenter,0.00001f)*P.side(PVector.sub(P.o,P.n),0.00001f)>0f){
        
          for(int j=0;j<mesh.vertices.size();j++){ 
            HE_Vertex v=(HE_Vertex)mesh.vertices.get(j);
            v.set(rotatePointAboutAxis(v,da,P.o,PVector.add(P.o,P.n)));         
           }
        
       mesh.clearSecondaries();
      }     
    }
    COUNTER++;
    if(COUNTER>100) ROTATING=false;

  }
if(SLIDING){
for(int i=0;i<meshes.size();i++){
      HE_Mesh mesh=(HE_Mesh)meshes.get(i);
      mesh.setBodyCenter();      
      if(P.side(mesh.bodyCenter,0.00001f)*P.side(PVector.sub(P.o,P.n),0.00001f)>0f){
        
          for(int j=0;j<mesh.vertices.size();j++){
            HE_Vertex v=(HE_Vertex)mesh.vertices.get(j);
            v.add(d);         
          }
        
        mesh.clearSecondaries();
      }     
    }
    COUNTER++;
    if(COUNTER>100) SLIDING=false;

  }

}





void buildMeshes(){
  meshes=new ArrayList();
    HE_Mesh mesh=new HE_Mesh();
    mesh=mesh.getBox(new PVector(),200,500,200);
   mesh.setBodyCenter();
    meshes.add(mesh);


}





void mouseClicked(){
 if(mouseButton==LEFT){  
    ArrayList newMeshes=new ArrayList();
    P=new Plane(new PVector(0,random(-200,200),0),new PVector(random(-1,1),10,random(-1,1)));
    d=P.n.cross(new PVector(random(-1,1),random(-1,1),random(-1,1)));
      d.normalize();
      d.mult(0.5f);
    for(int i=0;i<meshes.size();i++){  
      HE_Mesh mesh=(HE_Mesh)meshes.get(i);
      HE_Mesh[] result=mesh.splitMesh(P,false,true);//,false,true);
      if(result[0].vertices.size()>0)newMeshes.add(result[0]);
      if(result[1].vertices.size()>0)newMeshes.add(result[1]);

    }
    meshes=newMeshes;
    COUNTER=0;
    if(random(1.0)<2.0){
    ROTATING=true;
    SLIDING=false;
    da=random(-0.01,0.01);
    }
    else{
     SLIDING=true;
    ROTATING=false; 
      
    }
 }
    if(mouseButton==RIGHT){    
  buildMeshes();
   COUNTER=0;
    
    ROTATING=false;
    SLIDING=false;
    f=0;
    
}

}



void keyPressed(){
 f=1.5; 
}
