//Rudimentary plane class
class Plane{
  float A,B,C,D;
  PVector o;
  PVector n;

  Plane(final PVector p0, final PVector nn){
    n=nn.get();
    n.normalize();
    o=p0.get();
    A=n.x;
    B=n.y;
    C=n.z;

    D=-A*p0.x-B*p0.y-C*p0.z;
  }

  Plane(final PVector p0, final PVector p1, final PVector p2){
    A=p0.y*(p1.z-p2.z)+p1.y*(p2.z-p0.z)+p2.y*(p0.z-p1.z);
    B=p0.z*(p1.x-p2.x)+p1.z*(p2.x-p0.x)+p2.z*(p0.x-p1.x);
    C=p0.x*(p1.y-p2.y)+p1.x*(p2.y-p0.y)+p2.x*(p0.y-p1.y);
    n=new PVector(A,B,C);
    n.normalize();
    A=n.x;
    B=n.y;
    C=n.z;
    D=-A*p0.x-B*p0.y-C*p0.z;
    o=p0.get();

  }

  void update(){
        A=n.x;
    B=n.y;
    C=n.z;

    D=-A*o.x-B*o.y-C*o.z;
    
  }

  void flipNormal(){
    A*=-1;
    B*=-1;
    C*=-1;
    D*=-1;
    n.mult(-1);

  }

  //returns 1 if p is on same side as normal, -1 if on opposite side, 0 if on the plane
  float side(final PVector p, float threshold){
    float tmp=A*p.x+B*p.y+C*p.z+D;
    float result=0f;
    if(tmp<-threshold){
      result=-1f; 
    }
    else if(tmp>threshold){
      result=1f; 
    }

    return result;
  }

  float distanceToPlane(final PVector p){

    return abs(A*p.x+B*p.y+C*p.z+D);
  }
  
  boolean equals(Plane P,float threshold){
   boolean result=false; 
    float a=acos(n.x*P.n.x+n.y*P.n.y+n.z*P.n.z);
    float d=dist(o.x,o.y,o.z,P.o.x,P.o.y,P.o.z);
    if(a<threshold){
     result=(distanceToPlane(P.o)<threshold); 
    }
    //if(result) println(d+" "+a+" "+o+" "+P.o+" "+n+" "+P.n);
    return result;
  }
  
  
}


class Box{
  PVector center;
  PVector sides;
  boolean wFixed;
  boolean hFixed;
  boolean dFixed;
  
  
  Box(PVector c, float w, float h, float d){
    center=c.get();
    sides=new PVector(w,h,d);
    
  }
  
  void draw(){
   pushMatrix();
   translate(center.x,center.y,center.z);
   box(sides.x,sides.y,sides.z);  
  popMatrix(); 
    
  }
  
  boolean overlap(Box b){
    float dx=0.5f*(abs(sides.x)+abs(b.sides.x));
    float dy=0.5f*(abs(sides.y)+abs(b.sides.y));
    float dz=0.5f*(abs(sides.z)+abs(b.sides.z));
   return (abs(center.x-b.center.x)<dx)&&(abs(center.y-b.center.y)<dy)&&(abs(center.z-b.center.z)<dz);
    
    
  }
    boolean overlapx(Box b){
    float dx=0.5f*(abs(sides.x)+abs(b.sides.x));
   return abs(center.x-b.center.x)<dx  ;  
    
  }
      boolean overlapy(Box b){
    float dy=0.5f*(abs(sides.y)+abs(b.sides.y));
   return abs(center.y-b.center.y)<dy  ;  
    
  }    boolean overlapz(Box b){
    float dz=0.5f*(abs(sides.z)+abs(b.sides.z));
   return abs(center.z-b.center.z)<dz  ;  
    
  }
  
}

