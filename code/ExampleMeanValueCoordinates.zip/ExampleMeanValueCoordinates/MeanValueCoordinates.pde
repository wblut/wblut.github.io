
class MVC {
  float EPSILON=0.0001;
  float[][] points;
  int numPoints;
  float[][] values;
  int numValues;
  int[][] triangles;

  float[] d;
  float[] ux;
  float[] uy;
  float[] uz;


  MVC(float[][] values, float[][] points, int[][] triangles) {

    this.points=points;
    numPoints=points.length;
    assert(numPoints>0);
    this.values=values;  
    assert(values.length==numPoints);
    numValues=values[0].length;

    this.triangles=triangles;
    d=new float[numPoints];
    ux=new float[numPoints];
    uy=new float[numPoints];
    uz=new float[numPoints];
  }


  float[] getValues(float x, float y, float z) {
    assert(values.length==numPoints);

    for (int i = 0; i < numPoints; i++) {
      ux[i]=points[i][0]-x;
      uy[i]=points[i][1]-y;
      uz[i]=points[i][2]-z;
      d[i]=sqrt(ux[i]*ux[i]+uy[i]*uy[i]+uz[i]*uz[i]);  

      //Point is one of the mesh vertices, return value
      if (d[i]<EPSILON) return values[i];


      ux[i]/=d[i];
      uy[i]/=d[i];
      uz[i]/=d[i];
    }

    int i1, i2, i3;
    float l1, l2, l3, t1, t2, t3, h, w1, w2, w3, c1, c2, c3, s1, s2, s3, det;

    float[] totalF=new float[numValues];
    float[] totalW=new float[numValues];

    for (int i = 0; i < triangles.length; i ++) {
      i1 = triangles[i][0];
      i2 = triangles[i][1];
      i3 = triangles[i][2];

      //Degeneracie check
      l1=dist(ux[i2], uy[i2], uz[i2], ux[i3], uy[i3], uz[i3]);
      if (l1<EPSILON) continue;
      l2=dist(ux[i1], uy[i1], uz[i1], ux[i3], uy[i3], uz[i3]);
      if (l2<EPSILON) continue;
      l3=dist(ux[i2], uy[i2], uz[i2], ux[i1], uy[i1], uz[i1]);
      if (l3<EPSILON) continue;


      t1 = 2.0 * asin(0.5 * l1);
      t2 = 2.0 * asin(0.5 * l2);
      t3 = 2.0 * asin(0.5 * l3);
      h = 0.5 * (t1 + t2 + t3);

      //Point on triangle, do interpolation with barycentric coordinates
      if (abs(PI-h)<EPSILON) {
        w1 = sin(t1) * d[i3] * d[i2];
        w2 = sin(t2) * d[i1] * d[i3];
        w3 = sin(t3) * d[i2] * d[i1];
        float[] result=new float[numValues];
        for (int j=0; j<numValues; j++) {
          result[j]=  (w1 * values[i1][j] + w2 * values[i2][j] + w3 * values[i3][j]) / (w1 + w2 + w3);
        }
        return result;
      }
      
      //Point not on a triangle, do interpolation with mean value coordinates.
      det=orient3D(points[i1][0], points[i1][1], points[i1][2], points[i2][0], points[i2][1], points[i2][2], points[i3][0], points[i3][1], points[i3][2], x, y, z);
      c1 = min(max(2 * sin(h) * sin(h - t1) / sin(t2) / sin(t3) - 1.0, -1.0), 1.0);
      s1 = det * sqrt(1.0 - c1 * c1);
      if (abs(s1)<EPSILON)
        continue;
      c2 = min(max(2 * sin(h) * sin(h - t2) / sin(t3) / sin(t1) - 1.0, -1.0), 1.0);
      s2 = det * sqrt(1.0 - c2 * c2);
      if (abs(s2)<EPSILON)
        continue;
      c3 = min(max(2 * sin(h) * sin(h - t3) / sin(t1) / sin(t2) - 1.0, -1.0), 1.0);
      s3 = det * sqrt(1.0 - c3 * c3);
      if (abs(s3)<EPSILON)
        continue;
      w1 = (t1 - c2 * t3 - c3 * t2) / (d[i1] * sin(t3) * s2);
      w2 = (t2 - c3 * t1 - c1 * t3) / (d[i2] * sin(t1) * s3);
      w3 = (t3 - c1 * t2 - c2 * t1) / (d[i3] * sin(t2) * s1);
      for (int j=0; j<numValues; j++) {
        totalF[j]+=w1 * values[i1][j] + w2 * values[i2][j] + w3 * values[i3][j];
        totalW[j]+=w1 + w2 + w3;
      }
    }
    float[] result=new float[numValues];
    for (int j=0; j<numValues; j++) {
      result[j]=  totalF[j]/totalW[j];
    }
    return result;
  }


  //Not robust for (x,y,z) close to triangle abc, but that is no problem here since these points are handled before this is called
  float orient3D(float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz, float x, float y, float z) {
    final double adx = ax - x, bdx = bx - x, cdx = cx-x;
    final double ady = ay-y, bdy = by-y, cdy = cy-y;
    double adz = az-z, bdz = bz-z, cdz=cz-z;
    double adxbdy = adx * bdy;
    double adybdx = ady * bdx;
    double adxcdy = adx * cdy;
    double adycdx = ady * cdx;
    double bdxcdy = bdx * cdy;
    double bdycdx = bdy * cdx;
    final double m1 = adxbdy - adybdx;
    final double m2 = adxcdy - adycdx;
    final double m3 = bdxcdy - bdycdx;
    final double det = m1 * cdz - m2 * bdz + m3 * adz;
    return det > 0 ? 1 : det == 0 ? 0 : -1;
  }
}
