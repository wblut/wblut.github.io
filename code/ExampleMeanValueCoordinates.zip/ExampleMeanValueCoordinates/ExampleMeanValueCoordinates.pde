
MVC meanValueCoordinates;
int numPoints;
float[][] points;
float[] pointHues;
int[][] triangles;
float[][] values;

Wanderer[] wanderers;

void setup() {
  fullScreen(P3D);
  smooth(8);
  createMesh();
  createWanderers();
}

void createMesh() {
  //ICOSAHEDRON
  numPoints=12;
  points=new float[][] { { 0., 0., -0.951057 }, { 0., 0., 0.951057 }, { -0.850651, 0., -0.425325 }, { 0.850651, 0., 0.425325 }, 
    { 0.688191, -0.5, -0.425325 }, { 0.688191, 0.5, -0.425325 }, { -0.688191, -0.5, 0.425325 }, 
    { -0.688191, 0.5, 0.425325 }, { -0.262866, -0.809017, -0.425325 }, 
    { -0.262866, 0.809017, -0.425325 }, { 0.262866, -0.809017, 0.425325 }, 
    { 0.262866, 0.809017, 0.425325 } };

  for (int i=0; i<numPoints; i++) {
    for (int j=0; j<3; j++) {
      points[i][j]*=200.0;
    }
  }

  values=new float[numPoints][4];
  for (int i=0; i<numPoints; i++) {
    values[i][0]=random(256.0);
    values[i][1]=random(256.0);
    values[i][2]=random(256.0);
    values[i][3]=random(2.0, 4.0);
  }

  triangles=new int[][]{ { 1, 11, 7 }, { 1, 7, 6 }, { 1, 6, 10 }, { 1, 10, 3 }, { 1, 3, 11 }, { 4, 8, 0 }, { 5, 4, 0 }, 
    { 9, 5, 0 }, { 2, 9, 0 }, { 8, 2, 0 }, { 11, 9, 7 }, { 7, 2, 6 }, { 6, 8, 10 }, { 10, 4, 3 }, 
    { 3, 5, 11 }, { 4, 10, 8 }, { 5, 3, 4 }, { 9, 11, 5 }, { 2, 7, 9 }, { 8, 6, 2 } };

  meanValueCoordinates=new MVC(values, points, triangles);
}

void createWanderers() {
  int numWanderers=4000;
  wanderers=new Wanderer[numWanderers];
  for (int i=0; i<numWanderers; i++) {
    wanderers[i]=new Wanderer();
  }
}

void draw() {
  background(0);
  noLights();
  translate(width/2, height/2);
  rotateY(mouseX*1.0f/width*TWO_PI);
  rotateX(mouseY*1.0f/height*TWO_PI);
  drawMesh();
  drawWanderer();
  drawValues();
  rotateMesh();
}

void drawMesh() {
  strokeWeight(1.0);
  stroke(255);
  noFill();
  beginShape(TRIANGLES);
  for (int[] triangle : triangles) {
    for (int i=0; i<3; i++) {
      vertex(points[triangle[i]][0], points[triangle[i]][1], points[triangle[i]][2]);
    }
  }
  endShape();
}

void drawWanderer() {
  noStroke();
  for (Wanderer w : wanderers) {
    float[] localValues=meanValueCoordinates.getValues(w.x, w.y, w.z);
    fill(localValues[0], localValues[1], localValues[2]);
    pushMatrix();
    translate(w.x, w.y, w.z);
    box(localValues[3]);
    popMatrix();
    w.update();
  }
}

void drawValues() {
  noStroke();
  for (int i=0; i<numPoints; i++) {
    fill(values[i][0], values[i][1], values[i][2]);
    pushMatrix();
    translate(points[i][0], points[i][1], points[i][2]);
    box(3*values[i][3]);
    popMatrix();
  }
}

//https://sites.google.com/site/glennmurray/Home/rotation-matrices-and-formulas/rotation-about-an-arbitrary-axis-in-3-dimensions
void rotateMesh(){
 float u,v,w;
  u=v=w=1.0/sqrt(3.0);
  float theta=radians(0.5);
  float ct=cos(theta);
  float st=sin(theta);
  float x,y;
  float uxvywz;
  for(float[] point:points){
    uxvywz=u*point[0]+v*point[1]+w*point[2];
    x=u*uxvywz*(1.0-ct)+point[0]*ct+(v*point[2]-w*point[1])*st;
    y=v*uxvywz*(1.0-ct)+point[1]*ct+(w*point[0]-u*point[2])*st;
    point[2]=w*uxvywz*(1.0-ct)+point[2]*ct+(u*point[1]-v*point[0])*st;
    point[0]=x;
    point[1]=y;
    
  }
 
  
  
}

void mousePressed() {
  for (int i=0; i<numPoints; i++) {
    values[i][0]=random(256.0);
    values[i][1]=random(256.0);
    values[i][2]=random(256.0);
    values[i][3]=random(2.0, 5.0);
  }
}



class Wanderer {
  float x, y, z;
  float vx, vy, vz;

  Wanderer() {
    x=random(-1000, 1000);
    y=random(-200, 200);
    z=random(-600, 600); 
    vy=vz=0;
    vx=-random(0.5, 4.0);
  }

  void update() {
    
    if(x*x+y*y+z*z<22500){
    x+=0.15*vx;
    }else{
      x+=vx;
    }
    if (x<=-1000) x+=2000;
  }
}
