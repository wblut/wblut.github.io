class gridWalker {
  int x, y;
  int avgSteps;
  int stepCounter;
  int stepsToTake;
  int dir;
  boolean active;
  boolean crossedBoundary;
  color c;


  gridWalker() {
    x=0;
    y=0;
    avgSteps=1;
    stepCounter=0;
    stepsToTake=1;
    dir=0;
    active=false;
    crossedBoundary=false;
  }


  gridWalker(int xx, int yy, int aa) {
    x=xx;
    y=yy;
    avgSteps=aa;
    stepCounter=0;
    stepsToTake=poisson(aa);
    dir=constrain((int)random(4.0f), 0, 3);
    active=true;
    crossedBoundary=false;
    c=color((int)random(128));
  }

  void update() {
    crossedBoundary=false;
    switch(dir) {
    case 0: 
      x++;
      break;
    case 1: 
      x--;
      break;
    case 2: 
      y++;
      break;
    case 3: 
      y--;
      break;
    default:

      break;
    }
    stepCounter++;
  }

  void wrap(int xm, int xM, int ym, int yM) {
    while (x<xm) { 
      x+=xM-xm;
      crossedBoundary=true;
    }
    while (x>=xM) { 
      x-=xM-xm;
      crossedBoundary=true;
    }
    while (y<ym) { 
      y+=yM-ym;
      crossedBoundary=true;
    }
    while (y>=yM) { 
      y-=yM-ym;
      crossedBoundary=true;
    }
  }
}

int poisson(int avg) {
  float L=exp(-avg);
  int k=0;
  float p=1.0f;

  while (p>=L) {
    k++;
    p*=random(1.0f);
  }

  return (k-1);
}
