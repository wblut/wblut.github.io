class gridSystem{
  gridWalker[] walkers;
  int[][] grid;
  int width, height, numWalkers;


  gridSystem(){
  }

  gridSystem(int w, int h, int n){
    walkers=new gridWalker[n];
    grid=new int[w][h];
     /*for(int i=0;i<w;i++){
      for(int j=0;j<h;j++){
       
          grid[i][j]=(random(1.0f)<0.1)?1:0;
        
      }
    }*/
    numWalkers=n;
    width=w;
    height=h;
    for(int i=0;i<n;i++){    
      walkers[i]=new gridWalker(constrain((int)(random(0,w)),0,w-1),constrain((int)(random(0,h)),0,h-1),100);
      while(!checkPositionAvailability(walkers[i].x,walkers[i].y)){
        walkers[i].x=constrain((int)(random(0,w)),0,w-1);
        walkers[i].y=constrain((int)(random(0,h)),0,h-1);
      }
      grid[walkers[i].x][walkers[i].y]=1;
      while(!checkDirectionAvailability(walkers[i].dir, walkers[i].x,walkers[i].y)){
        walkers[i].dir=constrain((int)random(4.0f),0,3);
      }     
    }
  }

  boolean checkPositionAvailability(int x, int y){
    int xp=x+1;
    int xm=x-1;
    int yp=y+1;
    int ym=y-1;
    if(xp>=width) xp-=width;
    if(xm<0) xm+=width;
    if(yp>=height) yp-=height;
    if(ym<0) ym+=height;
    return((grid[x][y]==0)&&(grid[xp][y]*grid[xm][y]*grid[x][yp]*grid[x][ym]==0 ) );
  }

  boolean checkDirectionAvailability(int d,int x, int y){
    int xp=x+1;
    int xm=x-1;
    int yp=y+1;
    int ym=y-1;
    if(xp>=width) xp-=width;
    if(xm<0) xm+=width;
    if(yp>=height) yp-=height;
    if(ym<0) ym+=height;

    switch(d) {
    case 0: 
      return(grid[xp][y]==0);
    case 1: 
      return(grid[xm][y]==0);
    case 2: 
      return(grid[x][yp]==0);
    case 3: 
      return(grid[x][ym]==0);
    default:
      return false;
    }
  }

  void update(){
    for(int i=0;i<numWalkers;i++){
      
      if(checkDirectionAvailability(walkers[i].dir, walkers[i].x,walkers[i].y)){
        if(walkers[i].stepCounter<walkers[i].stepsToTake){
          walkers[i].update();
          walkers[i].wrap(0,width,0,height);
          grid[walkers[i].x][walkers[i].y]=1;
        }
        else{
          int tdir=walkers[i].dir;
          int trialCounter=0;
          walkers[i].dir=constrain((int)random(4.0f),0,3);
          walkers[i].stepCounter=0;
          walkers[i].stepsToTake=poisson(walkers[i].avgSteps);
          while(((walkers[i].dir==tdir)||(!checkDirectionAvailability(walkers[i].dir, walkers[i].x,walkers[i].y)))&&(trialCounter<100)){
            walkers[i].dir=constrain((int)random(4.0f),0,3);
            trialCounter++;
          }
          if(trialCounter==100) restartWalker(i);

        }

      }
      else{
        int tdir=walkers[i].dir;
          int trialCounter=0;
          walkers[i].dir=constrain((int)random(4.0f),0,3);
          walkers[i].stepCounter=0;
          walkers[i].stepsToTake=poisson(walkers[i].avgSteps);
          while(((walkers[i].dir==tdir)||(!checkDirectionAvailability(walkers[i].dir, walkers[i].x,walkers[i].y)))&&(trialCounter<100)){
            walkers[i].dir=constrain((int)random(4.0f),0,3);
            trialCounter++;
          }
          if(trialCounter==100) restartWalker(i);
        
      }


    }



  }

  void restartWalker(int index){
    walkers[index]=new gridWalker(constrain((int)(random(0,width)),0,width-1),constrain((int)(random(0,height)),0,height-1),100);
    while(!checkPositionAvailability(walkers[index].x,walkers[index].y)){
      walkers[index].x=constrain((int)(random(0,width)),0,width-1);
      walkers[index].y=constrain((int)(random(0,height)),0,height-1);
    }
    grid[walkers[index].x][walkers[index].y]=1;
    while(!checkDirectionAvailability(walkers[index].dir, walkers[index].x,walkers[index].y)){
      walkers[index].dir=constrain((int)random(4.0f),0,3);
    }    

  }




}
