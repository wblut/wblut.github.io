gridSystem g;

void setup(){
 fullScreen();
  background(120);
   g=new gridSystem(width,height,200);

}

void draw(){
 g.update();
 for(int i=0;i<g.numWalkers;i++){
 stroke(g.walkers[i].c);
   point(g.walkers[i].x,g.walkers[i].y);
 }
  stroke(255,100); 
 for(int i=0;i<g.numWalkers;i++){

   point(g.walkers[i].x+1,g.walkers[i].y+1);
 }
 stroke(0,100); 
 for(int i=0;i<g.numWalkers;i++){

   point(g.walkers[i].x-1,g.walkers[i].y-1);
 }

}
