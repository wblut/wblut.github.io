PShader matcap;
float range;

public void setup() {
  size(600, 600, P3D);
  smooth(8);
  matcap=loadShader("MatCapFrag.glsl", "MatCapVert.glsl");
  range=1.1;
  matcap.set("range", range);
  matcap.set("matcap", loadImage("500.png"));
}

void draw() {
  background(25);
  translate(width / 2, height / 2);
  rotateY(map(mouseX, 0, width, -PI, PI));
  rotateX(map(mouseY, 0, height, PI, -PI));
  scale(1.0);
  noLights();
  shader(matcap);
  noStroke();
  beginShape(TRIANGLES);
  for (int i=-40; i<40; i++) {
    for (int j=-40; j<40; j++) {
      vertex(i*4, j*4, bump(i, j));
      vertex((i+1)*4, j*4, bump(i+1, j));
      vertex((i+1)*4, (j+1)*4, bump(i+1, j+1));
      vertex(i*4, j*4, bump(i, j));
      vertex((i+1)*4, (j+1)*4, bump(i+1, j+1));
      vertex(i*4, (j+1)*4, bump(i, j+1));
    }
  }
  endShape();
}

float bump(int i, int j) {
  return 40*cos(radians(0.2*i*j));
}
