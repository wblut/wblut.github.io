PShader matcap;
float range;
PGraphics map;
float ax, ay;
public void setup() {
  size(600, 600, P3D);
  smooth(8);
  map=createGraphics(256, 256, P3D);
  map.smooth(8);
  matcap=loadShader("MatCapFrag.glsl", "MatCapVert.glsl");
  range=0.99;
  matcap.set("range", range);
}

void draw() {
  
  background(25);
  image(map, 10, 10, 64, 64, 0, 0, map.width, map.height);
  translate(width / 2, height / 2);
  rotateY(ay=radians(frameCount));
  rotateX(ax=PI/6.0);
  drawMap();
  noLights();
  matcap.set("matcap", map);
  shader(matcap);
  
  noStroke();
  
  beginShape(TRIANGLES);
  for (int i=-40; i<40; i++) {
    for (int j=-40; j<40; j++) {
      vertex(i*4, j*4, bump(i, j));
      vertex((i+1)*4, j*4, bump(i+1, j));
      vertex((i+1)*4, (j+1)*4, bump(i+1, j+1));
      vertex(i*4, j*4, bump(i, j));
      vertex((i+1)*4, (j+1)*4, bump(i+1, j+1));
      vertex(i*4, (j+1)*4, bump(i, j+1));
    }
  }
  endShape();

  resetShader();
}

void drawMap() {
  map.beginDraw();
  map.ortho();
  map.background(0);
  map.translate(map.width/2, map.height/2);
  map.rotateY(ay);
  map.rotateX(ax);
  int lightPhase=300;
  map.pointLight(255, 0, 255, 400*cos(radians(lightPhase)),400*sin(radians(lightPhase)), 0);
  map.pointLight(0, 255, 255, 0, 400*cos(0.8*radians(lightPhase+65)), 400*sin(0.8*radians(lightPhase+65)));
  map.pointLight(255, 255, 0, 400*cos(1.2*radians(lightPhase+130)), 0, 400*sin(1.2*radians(lightPhase+130)));
  map.noStroke();
  map.sphere(map.width/2);
  map.endDraw();
}

float bump(int i, int j) {
  return 40*cos(radians(0.2*i*j));
}
