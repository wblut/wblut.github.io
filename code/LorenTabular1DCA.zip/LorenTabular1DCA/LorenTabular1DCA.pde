WrappedLorenCA ca;
long seed;

void setup() {
  size(1024, 1024);
  // 3^9 possible rulesets, 19.683
  ca=new WrappedLorenCA(256, seed=(long)(Math.random()*19683));
}

void draw() {
  ca.draw(4,frameCount-1);
  ca.update();
  if(frameCount==256) noLoop();
}

//Click mouse for random ruleset
void mousePressed() {
  ca=new WrappedLorenCA(256, seed=(long)(Math.random()*19683));
  frameCount=0;
  loop();
}

//Press spacebar to save image with the seed as its name
void keyPressed() {
  if(key==' '){
  save(String.format("%012d", seed)+".png"); 
  ca=new WrappedLorenCA(256, seed=(long)(Math.random()*19683));
  frameCount=0;
  loop();
  }
}

class WrappedLorenCA {
  int N;
  boolean[] values;
  boolean[] buffer;
  int[][] rules;

  WrappedLorenCA(int N, long index) {
    N=max(N, 1);
    this.N=N;
    this.values=new boolean[N];
    this.buffer=new boolean[N];
    this.rules=new int[3][3];
    //The 9 entries of the ruleset are described by the seed in ternary notation
    for (int i=0; i<3; i++) {
      for (int j=0; j<3; j++) {
        this.rules[i][j]=(int)index%3;
        index/=3;
      }
    }
    init();
  }

  void init() {
    println(seed);
    for (int i=0; i<N; i++) {
        values[i]=random(100)<50;     
    }
  }

  int getN() {
    return N;
  }

  boolean update() {
    int row, col, rule;
    for (int i=0; i<N; i++) {
    
        //NEAREST NEIGHBORS
        row=0;
        if (getValue(i-1)) row++;
        if (getValue(i+1)) row++;
        //NEXT-NEAREST NEIGHBORS
        col=0;
        if (getValue(i-2)) col++;
        if (getValue(i+2)) col++;
        rule=rules[row][col];
        /*
        0: SWITCH OFF
        1: SWITCH ON
        2: UNCHANGED
        */
        setBufferValue(i, rule==0?false:rule==1?true:getValue(i));    
    }
    bufferToValues();
    return true;
  }

  boolean getValue(int i) {
    while (i<0) i+=N;
    return values[i%N];
  }

  void setValue(int i, boolean value) {
    while (i<0) i+=N;
    values[i%N]=value;
  }

  boolean getBufferValue(int i) {
    while (i<0) i+=N;
    return buffer[i%N];
  }

  void setBufferValue(int i, boolean value) {
    while (i<0) i+=N;
    buffer[i%N]=value;
  }

  boolean bufferToValues() { 
    boolean changed=false;
    for (int i=0; i<N; i++) {
        if (buffer[i]!=values[i]) {
          changed=true;
        } 
        values[i]=buffer[i];
      } 
    return changed;
  }

  void draw(int L, int offset) {
    pushStyle();
    noStroke(); 
    for (int i=0; i<N; i++) {
        fill(getValue(i)?0:255);
        rect(i*L, offset*L, L, L);
    }
    popStyle();
  }
}
