//Buffers for the frame averaging
float[] r;
float[] g;
float[] b;
//Camera settings
float fov;
float camz;
//Number of samples to average
int samples;

void setup() {
  fullScreen(P3D);
  smooth(8);
  noCursor();
  r=new float[width*height];
  g=new float[width*height];
  b=new float[width*height];
  //default camera settings
  fov=radians(60);
  camz=height/2/tan(0.5*fov);

  samples=256;
}

//Initialize the buffers
void initRGB() {
  for (int i=0; i<width*height; i++) {
    r[i]=0;
    g[i]=0;
    b[i]=0;
  }
}

//First draw the samples, when complete draw the average
void draw() {
  if (frameCount<=samples) {
    pushMatrix();
    drawSample();
    popMatrix();
    loadPixels();
    for (int i=0; i<pixels.length; i++) {
      r[i] += (pixels[i] >> 16 & 0xff);
      g[i] += (pixels[i] >> 8 & 0xff);
      b[i] += (pixels[i] & 0xff);
    }
    fill(0);
    textSize(20);
    text("sample "+frameCount+" of "+samples, 50, height-50);
  } else {
    loadPixels();
    for (int i=0; i<pixels.length; i++) {
      pixels[i] = 0xff << 24 | 
        int(r[i]/samples) << 16 | 
        int(g[i]/samples) << 8 | 
        int(b[i]/samples);
    }
    updatePixels();
    text("press spacebar to reset", 50, height-50);
    noLoop();
  }
}

//Draw a single sample
void drawSample() {
  background(55);
  sampleCameraInCone();
  drawThing();
}

//Pick a random camera position in a cone of angles,centered on the Z-axis,aimed at (0,0,0)
void sampleCameraInCone() {
  float angle= radians(1.0); // opening angle of camera cone
  float z =random(1.0)*(1.0-cos(angle))+cos(angle);
  float r = camz *sqrt(1.0 - z * z);
  float t = random(TWO_PI);
  camera(r * cos(t), r * sin(t), camz * z, 0, 0, 0, 0, 1, 0);
  perspective(fov, width/float(height), camz/10.0, camz*10.0);
}


void drawThing() {

  for (int i=-10; i<=10; i++) {
    for (int j=-10; j<=10; j++) {
      fill(128+12*i, 128-12*j, 2.4*i*j);
      pushMatrix();
      translate(40*i, 40*j, 4*i*j);
      box(10);
      popMatrix();
    }
  }
}

void keyPressed() {
  if(key==' '){
  frameCount=0;
  initRGB();
  loop();
  }
}
