
var isoSystem;
var firstFrame;
var lastFrame;
var axy, az;


var lamia;
var currentString;
var numStrings;
var lI=22;
var lJ=32;
var lK=22;

function preload() {
  lamia = loadStrings('data/lamia.txt');
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  colorMode(HSB);
  currentString=1;
  numStrings=lamia.length;
  let l=0;
  for (let i=0; i<lamia.length; i++) {
    if (lamia[i].length>l) {
      l=lamia[i].length;
    }
  }
  print(l);
  let L=Math.min(1.33*windowWidth, windowHeight)/60.0;
  isoSystem=new IsoSystem(L, lI, lJ, lK);
  
  create();
}

function create() {
  facade(this.lamia[currentString]);
  axy=0.0;
  az=0.0;
  isoSystem.mapVoxelsToHexGrid();
  firstFrame=millis();
  lastFrame=millis();
  currentString=(currentString+1)%numStrings;
}


function shrink() {
  let dj=Math.floor(random(-8, 9));
  print(dj);
  for (let i = 0; i < lI-3; i++) {
    for (let j = 0; j < lJ; j++) {
      for (let k = 0; k < lK-3; k++) {
        if (i==lI-4||k==lK-4) {
          if (isoSystem.voxelGrid.get(i+3, j+dj, k+3)) {
            isoSystem.voxelGrid.on(i, j, k);
          } else {
            isoSystem.voxelGrid.off(i, j, k);
          }
        } else {
          if (isoSystem.voxelGrid.get(i+1, j, k+1)) {
            isoSystem.voxelGrid.on(i, j, k);
          } else {
            isoSystem.voxelGrid.off(i, j, k);
          }
        }
      }
    }
  }

  for (let i = lI-3; i < lI; i++) {
    for (let j = 0; j < lJ; j++) {
      for (let k = 0; k < lK; k++) {
        isoSystem.voxelGrid.off(i, j, k);
      }
    }
  }

  for (let i = 0; i < lI-3; i++) {
    for (let j = 0; j < lJ; j++) {
      for (let k = lK-3; k < lK; k++) {
        isoSystem.voxelGrid.off(i, j, k);
      }
    }
  }
}

function facade(str) {
  let chrRow;
  let chr;
  let top=lJ-1-4;
  let ci;
  for (let i = 0; i < str.length; ) {
    ci=i;
    chrRow=[];
    for (let j = 0; j < min(str.length-ci, 11); j++) {
      if(j==0){
        while(str.charAt(i)==',' ){
         i++; 
        }
      }
      else if (j>6){
        if (str.charAt(i-1)== ' ' && str.charAt(i)!=' ' && str.charAt(i+1)!=' ') {
          break;
        }
      }
      chr=str.toLowerCase().charAt(i);
      chrRow.push(chr);

      i++;
    }
    row(top, chrRow);
    top-=5;
  }
} 


function row(top, chars) {
  let ribbon=[];
  for (let i = 0; i < 43; i++) {
    ribbon[i]=[];
  }
  let run=0;
  let pattern;
  let code;
  for (let c=0; c<14; c++) {
    code=code3x3(chars[c]);
    if (code>0) {
      pattern=getChar3x3(chars[c], 0, 0);
      for (let i = 0; i < 3; i++) {
        for (let j = 0; j <3; j++) {
          if (pattern[i][j]) {
            ribbon[run+i][j]=1;
          } else {
            ribbon[run+i][j]=0;
          }
        }
      }
    }
    run+=(code==0||code==9)?2:(code==3)?3:4;
  }

  for (let i=0; i<22; i++) {
    for (let j=0; j<3; j++) {
      if (ribbon[i][j]) {
        isoSystem.voxelGrid.on(i, top-j, lK-1);
      }
    }
  }
  for (let i=0; i<21; i++) {
    for (let j=0; j<3; j++) {
      if (ribbon[i+22][j]) {
        isoSystem.voxelGrid.on(lI-1, top-j, lK-2-i);
      }
    }
  }
}

function draw() {
  background(10);
  strokeWeight(2);
  
   var timeElapsed = millis() - lastFrame;
  axy+=timeElapsed/60000*TWO_PI;
  az+=timeElapsed/93000*TWO_PI;
  let shift=isoSystem.hexGrid.getGridCoordinates(isoSystem.I/2-isoSystem.K/2, isoSystem.J/2-isoSystem.K/2);
  translate(windowWidth/2+shift[0], windowHeight/2+shift[1]);
  scale(1, -1, 1);
  isoSystem.voxelGrid.calculateExposure(0.6+0.4*cos(axy), 0.7-0.3*cos(az), 0.5+0.5*cos(axy+PI));
  isoSystem.voxelGrid.diffuseExposure(0.12, 16);
  isoSystem.voxelGrid.smoothExposure(0.5,4);
  isoSystem.hexGrid.setExposure(isoSystem.voxelGrid);
  strokeWeight(1.0);
  isoSystem.drawTriangles();
  stroke(0);
  strokeWeight(1.4);
  isoSystem.drawLines();
  strokeWeight(2.2);
  isoSystem.drawOutlines();
 
 
  
  lastFrame=millis();
  if (lastFrame-firstFrame>10000) {
    firstFrame=lastFrame;
    shrink();
    create();
    lastFrame=millis();
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  let L=Math.min(1.33*windowWidth, windowHeight)/60.0;
  isoSystem.L=L;
  isoSystem.hexGrid.L=isoSystem.L;
}

class IsoHex {
  constructor(q, r) {
    this.q = q;
    this.r = r;
    this.colors = [];  
    this.region = [];
    this.part = [];  
    this.z = [];
    this.i = [];
    this.j = [];
    this.k  = [];
    this.orientation = [];
    this.exposures = [];
    this.minZ = 10000000;
    for (let f = 0; f < 6; f++) {
      this.colors[f] = -1;    
      this.region[f] = -1;
      this.part[f] = -1;
      this.z[f] = -10000000;
      this.i[f] = -10000000;
      this.j[f] = -10000000;
      this.k[f] = -10000000;
      this.orientation[f] = -1;
      this.exposures[f] = [0, 0, 0, 0, 0, 0];
    }
  }

  getIndices(f) {
    if (this.i[f] ==  -10000000) {
      return null;
    }
    return [this.i[f], this.j[f], this.k[f] ];
  }

  seti( f, id) {
    this.i[f]=id;
  }

  setj( f, id) {
    this.j[f]=id;
  }

  setk( f, id) {
    this.k[f]=id;
  }

  getOrientation(f) {
    return this.orientation[f];
  }

  getExposure(f, dir) {
    return this.exposures[f][dir];
  }

  isEmpty() {
    for (let f = 0; f < 6; f++) {
      if (this.orientation[f] > -1) {
        return 0;
      }
    }
    return 1;
  }

  getHash() {
    let A = (this.q >= 0 ? 2 *  this.q : -2 *  this.q - 1);
    let B = (this.r >= 0 ? 2 *  this.r : -2 *  this.r - 1);
    let C = ((A >= B ? A * A + A + B : A + B * B) / 2);
    return this.q < 0 && this.r < 0 || this.q >= 0 && this.r >= 0 ? C : -C - 1;
  }
}

class IsoSegment {
  constructor(q1, r1, q2, r2) {
    this.q1 = q1;
    this.r1 = r1;
    this.q2 = q2;
    this.r2 = r2;
    this.type = -1;
    this.lineValue = -1000000;
    this.sortValue = -1000000;
    if (q1 == q2) {
      this.type = 0;
      this.lineValue = q1;
      this.r1 = Math.min(r1, r2);
      this.r2 = Math.max(r1, r2);
      this.sortValue = this.r1;
    } else if (r1 == r2) {
      this.type = 1;
      this.lineValue = r1;
      this.q1 = Math.min(q1, q2);
      this.q2 = Math.max(q1, q2);
      this.sortValue = this.q1;
    } else if (-q1 + r1 == -q2 + r2) {
      this.type = 2;
      this.lineValue = -q1 + r1;
      if (q1 > q2) {
        this.q2 = q1;
        this.q1 = q2;
        this.r2 = r1;
        this.r1 = r2;
      }
      this.sortValue = this.q1;
    } else if (q1 + r1 == q2 + r2) {
      this.type = 3;
      this.lineValue = q1 + r1;
      if (r1 > r2) {
        this.r2 = r1;
        this.r1 = r2;
        this.q2 = q1;
        this.q1 = q2;
      }
      this.sortValue = this.r1;
    } else if (q1 - 2 * r1 == q2 - 2 * r2) {
      this.type = 4;
      this.lineValue = q1 - 2 * r1;
      if (r1 > r2) {
        this.r2 = r1;
        this.r1 = r2;
        this.q2 = q1;
        this.q1 = q2;
      }
      this.sortValue = this.r1;
    } else if (-2 * q1 + r1 == -2 * q2 + r2) {
      this.type = 5;
      this.lineValue = -2 * q1 + r1;
      if (q1 > q2) {
        this.q2 = q1;
        this.q1 = q2;
        this.r2 = r1;
        this.r1 = r2;
      }
      this.sortValue = this.q1;
    }
  }

  getHash() {
    let A = (this.type >= 0 ? 2 * this.type : -2 * this.type - 1);
    let B = (this.lineValue >= 0 ? 2 * this.lineValue : -2 * this.lineValue - 1);
    let  C = ((A >= B ? A * A + A + B : A + B * B) / 2);
    return this.type < 0 && this.lineValue < 0 || this.type >= 0 && this.lineValue >= 0 ? C : -C - 1;
  }
}

class IsoLine {
  constructor(type, value) {
    this.type = type;
    this.lineValue = value;
    this.segments=[];
  }

  addSegment(segment) {
    if (segment.type==this.type && segment.lineValue==this.lineValue) {
      this.segments.push(segment);
    }
  }

  lineSort() {
    this.segments.sort(function(a, b) {
      return a.sortValue-b.sortValue;
    }
    );
  }

  optimize() {
    let newSegments=[];
    let segi;
    let segj;
    for (let i=0; i<this.segments.length; ) {
      segi=this.segments[i];
      let j=0;
      for (j=i+1; j<this.segments.length; j++) {
        segj=this.segments[j];
        if (segj.q1==segi.q2 && segj.r1==segi.r2) {
          segi.q2=segj.q2;
          segi.r2=segj.r2;
        } else {
          break;
        }
      }
      i=j;
      newSegments.push(segi);
    }
    this.segments=newSegments;
  }
}

class IsoHexGrid {
  constructor(L) {
    this.L=L;
    this.centerIndex = 6;
    this.vertexOffsets = [ 1, 0, 1, 1, 0, 1, -1, 0, -1, -1, 0, -1, 0, 0];
    this.triangleVertices = [[this.centerIndex, 0, 1 ], [ this.centerIndex, 1, 2 ], 
      [ this.centerIndex, 2, 3 ], [ this.centerIndex, 3, 4 ], [ this.centerIndex, 4, 5 ], [ this.centerIndex, 5, 0 ]];
    this.c60 = 0.5;
    this.s60 = 0.86602540;
    this.interHexNeighbor = [ 3, 4, 5, 0, 1, 2 ];
    this.interHexSegment = [ 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 0];
    this.interHexNeighborQ = [ +2, +1, -1, -2, -1, 1 ];
    this.interHexNeighborR = [ +1, +2, 1, -1, -2, -1 ];
    this.interTriangleNeighbor = [ 1, 2, 3, 4, 5, 0 ];
    this.interTriangleSegment = [ this.centerIndex, 1, this.centerIndex, 2, this.centerIndex, 3, this.centerIndex, 
      4, this.centerIndex, 5, this.centerIndex, 0 ];
    this.mapTrianglesFromPosOne = [4, 3, 0, 5, 2, 1 ];
    this.mapQFromPosOne = [1, 1, -1, -1, 0, 0 ];
    this.mapRFromPosOne = [1, 1, 0, 0, -1, -1 ];
    this.mapTrianglesFromNegOne = [2, 5, 4, 1, 0, 3 ];
    this.mapQFromNegOne = [1, 0, 0, -1, -1, 1 ];
    this.mapRFromNegOne = [0, 1, 1, -1, -1, 0 ];
    this.triangleOrientations = [ 0, 1, 1, 2, 2, 0 ];
    this.offsets = [];
    for (let i = 0; i < 7; i++) {
      this.offsets[2 * i] = this.vertexOffsets[2 * i] * this.s60;
      this.offsets[2 * i + 1] = (this.vertexOffsets[2 * i + 1] - this.vertexOffsets[2 * i] * this.c60);
    }
    this.cells=[];
    this.linesMap={};
    this.outlinesMap={};
    this.lines=[];
    this.outlines=[];
  }

  getCellHash( q, r) {
    let A = (q >= 0 ? 2 * q : -2 * q - 1);
    let B = (r >= 0 ? 2 * r : -2 * r - 1);
    let C = ((A >= B ? A * A + A + B : A + B * B) / 2);
    return q < 0 && r < 0 || q >= 0 && r >= 0 ? C : -C - 1;
  }

  setParts(voxels) {
    let cell;
    for (let key in this.cells) {
      cell=this.cells[key];
      for (let f = 0; f < 6; f++) {
        if (cell.orientation[f] > -1) {
          cell.part[f] = voxels.part(cell.i[f], cell.j[f], cell.k[f]);
        }
      }
    }
  }

  setRegions() {
    let maxRegion = -1;
    let cell;
    for ( let key in this.cells) {
      cell=this.cells[key];
      for (let f = 0; f < 6; f++) {
        if (cell.orientation[f] > -1 && cell.part[f]>-1) {
          cell.region[f] =3* cell.part[f] + cell.orientation[f];
          maxRegion = Math.max(cell.region[f], maxRegion);
        } else {
          cell.region[f] = -1;
        }
      }
    }
  }

  setExposure(voxels) {
    let cell;
    for (let key in this.cells) {
      cell=this.cells[key];
      for (let f = 0; f < 6; f++) {
        for (let d=0; d<6; d++) {
          if (cell.orientation[f] > -1 && cell.part[f]>-1) {
            cell.exposures[f][d] = voxels.exposure(cell.i[f], cell.j[f], cell.k[f], d);
          }
        }
      }
    }
  }

  addTriangle(q, r, s, zz, orient, col, ii, jj, kk) {
    let key = this.getCellHash(q, r);
    let cell=this.cells[key];
    if (!cell) {
      cell=new IsoHex(q, r);
      this.cells[key]=cell;
    }
    if (zz > cell.z[s]) {
      cell.orientation[s] = orient;
      cell.z[s] = zz;
      cell.colors[s] = col;
      cell.i[s]=ii;
      cell.j[s]=jj;
      cell.k[s]=kk;
      cell.part[s] = -1;
    }
  }

  addVoxel(ii, jj, kk, col) {
    let zz = ii + jj + kk;
    let q = ii - kk;
    let r = jj - kk;
    let layer = q+r;
    layer=layer-3*Math.floor((layer+1)/3);
    while (layer > 1) {
      layer -= 3;
    }

    while (layer < -1) {
      layer += 3;
    }

    let ns;
    switch (layer) {
    case 0:
      for (let s = 0; s < 6; s++) {
        if (this.triangleOrientations[s] >= 0) {
          this.addTriangle(q, r, s, zz, this.triangleOrientations[s], col, ii, jj, kk);
        }
      }
      break;
    case +1:
      for (let s = 0; s < 6; s++) {
        ns = this.mapTrianglesFromPosOne[s];
        if (this.triangleOrientations[s] >= 0) {
          this.addTriangle(q + this.mapQFromPosOne[s], r + this.mapRFromPosOne[s], ns, zz, this.triangleOrientations[s], col, ii, jj, kk);
        }
      }
      break;
    case -1:
      for (let s = 0; s < 6; s++) {
        ns = this.mapTrianglesFromNegOne[s];
        if (this.triangleOrientations[s] >= 0) {
          this.addTriangle(q + this.mapQFromNegOne[s], r + this.mapRFromNegOne[s], ns, zz, this.triangleOrientations[s], col, ii, jj, kk);
        }
      }
      break;
    default:
    }
  }

  getGridCoordinates(q, r) {
    return [q*this.s60*this.L, (r-q*this.c60)*this.L];
  }

  triVertex(t, i, center) {
    vertex(center[0]+this.offsets[2 * this.triangleVertices[t][i]] * this.L, center[1]+this.offsets[2 * this.triangleVertices[t][i] + 1] * this.L);
  }

  triVertices(t, center) {
    this.triVertex(t, 0, center);
    this.triVertex(t, 1, center);
    this.triVertex(t, 2, center);
  }

  hexVertex(i, center) {
    vertex(center[0]+this.offsets[2 * i] * this.L, center[1]+this.offsets[2 * i + 1] * this.L);
  }

  collectLines() {
    this.outlinesMap={};
    this.collectInterHexSegmentsOutline();
    this.collectInterTriangleSegmentsOutline();
    this.outlines =[];
    for (let key in this.outlinesMap) {

      this.outlines.push(this.outlinesMap[key]);
    }
    let line;
    for (let i =0; i<this.outlines.length; i++) {
      line=this.outlines[i];
      line.lineSort();
      line.optimize();
    }

    this.linesMap={};
    this.collectInterHexSegmentsInterior();
    this.collectInterTriangleSegmentsInterior();
    this.lines =[];
    for (let key in this.linesMap) {
      this.lines.push(this.linesMap[key]);
    }

    for (let i =0; i<this.lines.length; i++) {
      line=this.lines[i];
      line.lineSort();
      line.optimize();
    }
  }

  areSeparate(orientation1, orientation2, palette1, palette2, z1, z2) {
    return orientation1 != orientation2 || palette1 != palette2 || Math.abs(z1 - z2) > 1;
  }

  collectInterHexSegmentsInterior() {
    let neighbor;
    let nz;
    let norientation;
    let ncolorIndex;
    let npart;
    let hash;
    let nhash;
    let cell;
    for (let key in this.cells) {
      cell=this.cells[key];
      hash = this.getCellHash(cell.q, cell.r);
      for (let i = 0; i < 6; i++) {
        if (cell.orientation[i] >= 0) {
          if (this.interHexNeighbor[i] >= 0) {
            neighbor = this.getNeighbor(cell.q, cell.r, i);
            if (neighbor) {
              nhash = this.getCellHash(cell.q + this.interHexNeighborQ[i], cell.r + this.interHexNeighborR[i]);
              norientation = neighbor.orientation[this.interHexNeighbor[i]];
              npart = neighbor.part[this.interHexNeighbor[i]];
              if (cell.part[i] == npart && (nhash < hash ||norientation == -1)) {

                nz = neighbor.z[this.interHexNeighbor[i]];
                ncolorIndex = neighbor.colors[this.interHexNeighbor[i]];
                if (this.areSeparate(norientation, cell.orientation[i], ncolorIndex, cell.colors[i], 
                  cell.z[i], nz)) {
                  this.addSegmentToLines(cell.q, cell.r, this.interHexSegment[2 * i], 
                    this.interHexSegment[2 * i + 1]);
                }
              }
            }
          }
        }
      }
    }
  }

  collectInterHexSegmentsOutline() {   
    let neighbor;
    let norientation;
    let npart;
    let hash;
    let nhash;
    let cell;
    for (let key in this.cells) {
      cell=this.cells[key];
      hash = this.getCellHash(cell.q, cell.r);
      for (let i = 0; i < 6; i++) {
        if (cell.orientation[i] >= 0) {
          neighbor = this.getNeighbor(cell.q, cell.r, i);
          if (!neighbor) {
            this.addSegmentToOutlines(cell.q, cell.r, this.interHexSegment[2 * i], this.interHexSegment[2 * i + 1]);
          } else {
            nhash = this.getCellHash(cell.q + this.interHexNeighborQ[i], cell.r + this.interHexNeighborR[i]);
            norientation = neighbor.orientation[this.interHexNeighbor[i]];
            if (nhash < hash || norientation == -1) {
              npart = neighbor.part[this.interHexNeighbor[i]];
              if (cell.part[i] != npart) {
                this.addSegmentToOutlines(cell.q, cell.r, this.interHexSegment[2 * i], this.interHexSegment[2 * i + 1]);
              }
            }
          }
        }
      }
    }
  }

  collectInterTriangleSegmentsInterior() {
    let z;
    let orientation;
    let palette;
    let part;
    let cell;
    for (let key in this.cells) {
      cell=this.cells[key];
      for (let i = 0; i < 6; i++) {
        orientation = cell.orientation[this.interTriangleNeighbor[i]];
        z = cell.z[this.interTriangleNeighbor[i]];
        palette = cell.colors[this.interTriangleNeighbor[i]];
        part = cell.part[this.interTriangleNeighbor[i]];
        if (cell.part[i] != part) {
        } else if (this.areSeparate(orientation, cell.orientation[i], palette, cell.colors[i], cell.z[i], 
          z)) {
          this.addSegmentToLines(cell.q, cell.r, this.interTriangleSegment[2 * i], this.interTriangleSegment[2 * i + 1]);
        }
      }
    }
  }

  collectInterTriangleSegmentsOutline() {
    let part;
    let cell;
    for (let key in this.cells) {
      cell=this.cells[key];
      for (let i = 0; i < 6; i++) {

        part = cell.part[this.interTriangleNeighbor[i]];
        if (cell.part[i] != part) {
          this.addSegmentToOutlines(cell.q, cell.r, this.interTriangleSegment[2 * i], this.interTriangleSegment[2 * i + 1]);
        }
      }
    }
  }

  getNeighbor( q, r, i) {
    return this.cells[this.getCellHash(q + this.interHexNeighborQ[i], r + this.interHexNeighborR[i])];
  }

  addSegmentToLines(q, r, i1, i2) {
    let segment = new IsoSegment(q + this.vertexOffsets[2 * i1], 
      r + this.vertexOffsets[2 * i1 + 1], 
      q + this.vertexOffsets[2 * i2], 
      r + this.vertexOffsets[2 * i2 + 1]);
    let key = segment.getHash();
    let line = this.linesMap[key];
    if (!line) {
      line = new IsoLine(segment.type, segment.lineValue);
      this.linesMap[key]= line;
    }
    line.addSegment(segment);
  }

  addSegmentToOutlines(q, r, i1, i2) {
    let segment = new IsoSegment(q + this.vertexOffsets[2 * i1], 
      r + this.vertexOffsets[2 * i1 + 1], 
      q + this.vertexOffsets[2 * i2], 
      r + this.vertexOffsets[2 * i2 + 1]);
    let key = segment.getHash();
    let line = this.outlinesMap[key];
    if (!line) {
      line = new IsoLine(segment.type, segment.lineValue);
      this.outlinesMap[key]= line;
    }
    line.addSegment(segment);
  }
}

class VoxelGrid {
  constructor(I, J, K) {
    this.I=I;
    this.J=J;
    this.K=K;
    this.JK=J*K;
    this.IJK=I*this.JK;
    this.voxels = [];
    this.parts =[];
    this.colors = [];
    this.visited=[];
    this.accessibilities=[];
    this.exposures=[];
    for (let id=0; id<this.IJK; id++) {
      this.accessibilities[id]=[]; 
      this.exposures[id]=[];
    }
    this.exposuresBuffer=[];
    for (let id=0; id<this.IJK; id++) {
      this.exposuresBuffer[id]=[];
    }
  }

  get(i, j, k) {
    let id =i;
    if (typeof j!== 'undefined') {
      id = this.index(i, j, k);
    }
    if (id>-1 && id<this.IJK) {
      if (! this.voxels[id]) {
        return 0;
      } else {
        return this.voxels[id];
      }
    }
    return 0;
  }

  exposure(i, j, k, s) {
    let id =i;
    if (typeof j!== 'undefined') {
      id = this.index(i, j, k);
    }
    if (id>-1 && id <this.IJK) {
      if (! this.exposures[id][s]) {
        return -1;
      } else {
        return this.exposures[id][s];
      }
    }
    return -1;
  }

  part(i, j, k) {
    let id =i;
    if (typeof j!== 'undefined') {
      id = this.index(i, j, k);
    }
    if (id>-1 && id <this.IJK) {
      if (! this.voxels[id]) {
        return -1;
      } else {
        return this.parts[id];
      }
    }
    return -1;
  }

  col(i, j, k) {
    let id =i;
    if (typeof j!== 'undefined') {
      id = this.index(i, j, k);
    }
    if (id>-1 && id <this.IJK) {
      if (! this.colors[id]) {
        return -1;
      } else {
        return this.colors[id];
      }
    }
    return -1;
  }

  accessibility(i, j, k, s) {
    let id =i;
    if (typeof j!== 'undefined') {
      id = this.index(i, j, k);
    }
    if (id>-1 && id <this.IJK) {
      if (! this.accessibilities[id]) {
        return -1;
      } else {
        return this.accessibilities[id][s];
      }
    }
    return -1;
  }

  index(i, j, k) {
    if (i<0 || i>this.I-1 || j<0 || j>this.J-1 || k<0 || k>this.K-1) {
      return -1;
    }
    return i*this.JK+j*this.K+k;
  }


  on(i, j, k) {
    let id =i;
    if (typeof j!== 'undefined') {
      id = this.index(i, j, k);
    }
    if (id>-1 && id<this.IJK) {
      this.voxels[id]=1;
    }
  }

  off(i, j, k) {
    let id =i;
    if (typeof j!== 'undefined') {
      id = this.index(i, j, k);
    }
    if (id>-1 && id<this.IJK) {
      this.voxels[id]=0;
    }
  }

  setColor(i, j, k, col) {
    let id =i;
    if (typeof j!== 'undefined') {
      id = this.index(i, j, k);
    }
    if (id>-1 && id<this.IJK) {
      this.colors[id]=col;
    }
  }

  labelParts() {
    for (let id = 0; id < this.IJK; id++) {
      this.visited[id] = 0;
    }
    let currentPart = 0;
    let indices;
    do {
      indices = this.findSeed();
      if (indices) {
        this.floodFill(indices[0], indices[1], indices[2], currentPart);
        currentPart++;
      }
    } while (indices);
    return currentPart;
  }

  findSeed() {
    let id=0;
    for (let i = 0; i < this.I; i++) {
      for (let j = 0; j < this.J; j++) {
        for (let k = 0; k < this.K; k++) {
          if (this.visited[id]==0 && this.voxels[id]==1) {
            return [i, j, k];
          }
          id++;
        }
      }
    }
    return null;
  }

  floodFill(i, j, k, part) {
    let count = 0;
    let queuei=[i];
    let queuej=[j];
    let queuek=[k];
    let celli;
    let cellj;
    let cellk;
    while (queuei.length) {
      celli = queuei.pop();
      cellj = queuej.pop();
      cellk = queuek.pop();
      if (this.floodFillDo(celli, cellj, cellk, part)) {
        count++;
        queuei.push(celli - 1);
        queuei.push(celli + 1);
        queuei.push(celli);
        queuei.push(celli);
        queuei.push(celli);
        queuei.push(celli);
        queuej.push(cellj);
        queuej.push(cellj);
        queuej.push(cellj - 1);
        queuej.push(cellj + 1);
        queuej.push(cellj);
        queuej.push(cellj);
        queuek.push(cellk);
        queuek.push(cellk);
        queuek.push(cellk);
        queuek.push(cellk);
        queuek.push(cellk - 1);
        queuek.push(cellk + 1);
      }
    }
    return count;
  }

  floodFillDo(i, j, k, part) {
    let id=this.index(i, j, k);
    if (id == -1) {
      return 0;
    }
    if (this.visited[id]) {
      return 0;
    }
    if (!this.voxels[id]) { 
      return 0;
    }
    this.parts[id] = part;
    this.visited[id] = 1;
    return 1;
  }

  fill() {
    for (let id = 0; id < this.IJK; id++) {
      voxels[id] = 1;
    }
  }

  clear() {
    for (let id = 0; id < yhis.IJK; id++) {
      voxels[id] = 0;
    }
  }

  setMaxAccessibilityAtBoundaries(cutoff) {
    let id = 0;
    for (let i = 0; i < this.I; i++) {
      id = i * this.JK;
      for (let k = 0; k < this.K; k++) {
        for (let j = 0; j < this.J; j++) {
          this.accessibilities[id + j * this.K][2] = cutoff;
          if (this.get(id + j * this.K)) {
            break;
          }
        }
        for (let j = this.J - 1; j >= 0; j--) {
          this.accessibilities[id + j * this.K][3] = cutoff;
          if (this.get(id + j * this.K)) {
            break;
          }
        }
        id++;
      }
    }

    for (let i = 0; i < this.I; i++) {
      id = i * this.JK;
      for (let j = 0; j < this.J; j++) {
        for (let k = 0; k < this.K; k++) {
          this.accessibilities[ id + k][4] = cutoff;
          if (this.get(id + k)) {
            break;
          }
        }
        for (let k = this.K - 1; k >= 0; k--) {
          this.accessibilities[ id + k][5] = cutoff;
          if (this.get(id + k)) {
            break;
          }
        }
        id += this.K;
      }
    }

    for (let j = 0; j < this.J; j++) {
      id = j * this.K;
      for (let k = 0; k < this.K; k++) {
        for (let i = 0; i < this.I; i++) {
          this.accessibilities[ id + i * this.JK][0] = cutoff;
          if (this.get(id + i * this.JK)) {
            break;
          }
        }
        for (let i = this.I - 1; i >= 0; i--) {
          this.accessibilities[id + i * this.JK][1] = cutoff;
          if (this.get(id + i * this.JK)) {
            break;
          }
        }
        id++;
      }
    }
  }

  scanInteriorCubes(cutoff) {
    let id = 0;
    for (let i = 0; i < this.I; i++) {
      for (let j = 0; j < this.J; j++) {
        for (let k = 0; k < this.K; k++) {
          if (!this.accessibilities[id][0] || this.accessibilities[id][0] < cutoff) {
            this.accessibilities[id][0]= this.scanILeft(i, id, cutoff);
          }
          if (!this.accessibilities[id][1] ||this.accessibilities[id][1] < cutoff) {
            this.accessibilities[id][1]= this.scanIRight(i, id, cutoff);
          }
          if (!this.accessibilities[id][2] ||this.accessibilities[id][2] < cutoff) {
            this.accessibilities[id][2] =this.scanJLeft(j, id, cutoff);
          }
          if (!this.accessibilities[id][3] ||this.accessibilities[id][3] < cutoff) {
            this.accessibilities[id][3]= this.scanJRight(j, id, cutoff);
          }
          if (!this.accessibilities[id][4] ||this.accessibilities[id][4] < cutoff) {
            this.accessibilities[id][4] =this.scanKLeft(k, id, cutoff);
          }
          if (!this.accessibilities[id][5] ||this.accessibilities[id][5] < cutoff) {
            this.accessibilities[id][5]= this.scanKRight(k, id, cutoff);
          }
          id++;
        }
      }
    }
  }

  scanILeft( i, id, cutoff) {
    let count = 0;
    for (let ci = i - 1; ci >= 0; ci--) {
      if (this.get(id + (ci - i) * this.JK)) {
        break;
      }
      count++;
      if (count >= cutoff) {
        break;
      }
    }
    return count;
  }

  scanIRight(i, id, cutoff) {
    let count = 0;
    for (let ci = i + 1; ci < this.I; ci++) {
      if (this.get(id + (ci - i) * this.JK)) {
        break;
      }
      count++;
      if (count >= cutoff) {
        break;
      }
    }
    return count;
  }

  scanJLeft(j, id, cutoff) {
    let count = 0;

    for (let cj = j - 1; cj >= 0; cj--) {
      if (this.get(id + (cj - j) * this.K)) {
        break;
      }
      count++;
      if (count >= cutoff) {
        break;
      }
    }
    return count;
  }

  scanJRight(j, id, cutoff) {
    let count = 0;
    for (let cj = j + 1; cj < this.J; cj++) {
      if (this.get(id + (cj - j) * this.K)) {
        break;
      }
      count++;
      if (count >= cutoff) {
        break;
      }
    }
    return count;
  }

  scanKLeft(k, id, cutoff) {
    let count = 0;
    for (let ck = k - 1; ck >= 0; ck--) {
      if (this.get(id + ck - k)) {
        break;
      }
      count++;
      if (count >= cutoff) {
        break;
      }
    }
    return count;
  }

  scanKRight(k, id, cutoff) {
    let count = 0;
    for (let ck = k + 1; ck < this.K; ck++) {
      if (this.get(id + ck - k)) {
        break;
      }
      count++;
      if (count >= cutoff) {
        break;
      }
    }
    return count;
  }

  calculateExposure(di, dj, dk) {
    let dv =[ di, di, dj, dj, dk, dk ];
    let id = 0;
    for (let i = 0; i <  this.I; i++) {
      for (let j = 0; j <  this.J; j++) {
        for (let k = 0; k <  this.K; k++) {
          for (let side = 0; side < 6; side++) {
            this.exposures[id][side] = dv[side] * this.accessibilities[id][side];
          }
          id++;
        }
      }
    }
  }

  diffuseExposure(bf, cutoff) {
    let id = 0;
    let bounceFactor = [];
    for (let i = 0; i < this.I; i++) {
      for (let j = 0; j < this.J; j++) {
        for (let k = 0; k < this.K; k++) {
          if (this.voxels[id]) {
            for (let side = 0; side < 6; side++) {
              this.exposuresBuffer[id][side] = this.exposures[id][side];
              bounceFactor[side] = (1.0 - this.accessibilities[id][side] / cutoff) * bf;
            }

            for (let side = 0; side < 6; side++) {
              for (let oside = 0; oside < 6; oside++) {
                if (Math.floor(side / 2) != Math.floor(oside / 2)) {
                  this.exposuresBuffer[id][side] += bounceFactor[side]* this.exposures[id][oside];
                }
              }
            }

            if (j > 0) {
              this.exposuresBuffer[id][0] += bounceFactor[0] * this.exposures[(id - this.K)][2];
              this.exposuresBuffer[id][1] += bounceFactor[1] * this.exposures[(id - this.K)][2];
            }
            if (j < this.J - 1) {
              this.exposuresBuffer[id][0] += bounceFactor[0] * this.exposures[(id + this.K)][3];
              this.exposuresBuffer[id][1] += bounceFactor[1] * this.exposures[(id + this.K)][3];
            }
            if (k > 0) {
              this.exposuresBuffer[id][0] += bounceFactor[0] * this.exposures[(id - 1)][4];
              this.exposuresBuffer[id][1] += bounceFactor[1] * this.exposures[(id - 1)][4];
            }
            if (k < this.K - 1) {
              this.exposuresBuffer[id][0] += bounceFactor[0] * this.exposures[(id + 1)][5];
              this.exposuresBuffer[id][1] += bounceFactor[1] * this.exposures[(id + 1)][5];
            }
            if (i > 0) {
              this.exposuresBuffer[id][2] += bounceFactor[2] * this.exposures[(id - this.JK)][0];
              this.exposuresBuffer[id][3] += bounceFactor[3] * this.exposures[(id - this.JK)][0];
            }
            if (i < this.I - 1) {
              this.exposuresBuffer[id][2] += bounceFactor[2] * this.exposures[(id + this.JK)][1];
              this.exposuresBuffer[id][3] += bounceFactor[3] * this.exposures[(id + this.JK)][1];
            }
            if (k > 0) {
              this.exposuresBuffer[id][2] += bounceFactor[2] * this.exposures[(id - 1)][4];
              this.exposuresBuffer[id][3] += bounceFactor[3] * this.exposures[(id - 1)][4];
            }
            if (k < this.K - 1) {
              this.exposuresBuffer[id][2] += bounceFactor[2] * this.exposures[(id + 1)][5];
              this.exposuresBuffer[id][3] += bounceFactor[3] * this.exposures[(id + 1)][5];
            }
            if (i > 0) {
              this.exposuresBuffer[id][4] += bounceFactor[4] * this.exposures[(id - this.JK)][0];
              this.exposuresBuffer[id][5] += bounceFactor[5] * this.exposures[(id - this.JK)][0];
            }
            if (i < this.I - 1) {
              this.exposuresBuffer[id][4] += bounceFactor[4] * this.exposures[(id + this.JK)][1];
              this.exposuresBuffer[id][5] += bounceFactor[5] * this.exposures[(id + this.JK)][1];
            }
            if (j > 0) {
              this.exposuresBuffer[id][4] += bounceFactor[4] * this.exposures[(id - this.K)][2];
              this.exposuresBuffer[id][5] += bounceFactor[5] * this.exposures[(id - this.K)][2];
            }
            if (j < this.J - 1) {
              this.exposuresBuffer[id][4] += bounceFactor[4] * this.exposures[(id + this.K)][3];
              this.exposuresBuffer[id][5] += bounceFactor[5] * this.exposures[(id + this.K)][3];
            }
          }
          id++;
        }
      }
    }
    let tmp = this.exposures;
    this.exposures = this.exposuresBuffer;
    this.exposuresBuffer = tmp;
  }

  smoothExposure( smoothFactor, iter) {


    let tmp=[];

    for (let r = 0; r < iter; r++) {

      let id = 0;
      let w;
      for (let i = 0; i < this.I; i++) {
        for (let j = 0; j < this.J; j++) {
          for (let k = 0; k < this.K; k++) {
            for (let side = 0; side < 6; side++) {
              this.exposuresBuffer[id][side] = this.exposures[id][side];
            }
            if (this.voxels[id]) {
              w = 1.0;
              if (i == 0 || !this.voxels[id - this.JK]) {// left side open
                if (j > 0 && this.voxels[id - this.K] && (i == 0 || !this.voxels[id - this.K - this.JK])) {
                  this.exposuresBuffer[id][0] += smoothFactor * this.exposures[(id - this.K)][0];
                  w += smoothFactor;
                }
                if (j < this.J - 1 && this.voxels[id + this.K] && (i == 0 || !this.voxels[id + this.K - this.JK])) {
                  this.exposuresBuffer[id][0] += smoothFactor * this.exposures[(id + this.K)][0];
                  w += smoothFactor;
                }
                if (k > 0 && this.voxels[id - 1] && (i == 0 || !this.voxels[id - 1 - this.JK])) {

                  this.exposuresBuffer[id][0] += smoothFactor * this.exposures[(id - 1)][0];
                  w += smoothFactor;
                }
                if (k < this.K - 1 && this.voxels[id + 1] && (i == 0 || !this.voxels[id + 1 - this.JK])) {
                  this.exposuresBuffer[id][0] += smoothFactor * this.exposures[(id + 1)][0];
                  w += smoothFactor;
                }
              }

              this.exposuresBuffer[id][0] /= w;

              w = 1.0;
              if (i == this.I - 1 || !this.voxels[id + this.JK]) {// right side open
                if (j > 0 && this.voxels[id - this.K] && (i == this.I - 1 || !this.voxels[id - this.K + this.JK])) {
                  this.exposuresBuffer[id][1] += smoothFactor * this.exposures[(id - this.K)][1];
                  w += smoothFactor;
                }
                if (j < this.J - 1 && this.voxels[id + this.K] && (i == this.I - 1 || !this.voxels[id + this.K + this.JK])) {
                  this.exposuresBuffer[id][1] += smoothFactor * this.exposures[(id + this.K)][1];
                  w += smoothFactor;
                }
                if (k > 0 && this.voxels[id - 1] && (i == this.I - 1 || !this.voxels[id - 1 + this.JK])) {

                  this.exposuresBuffer[id][1] += smoothFactor * this.exposures[(id - 1)][1];
                  w += smoothFactor;
                }
                if (k < this.K - 1 && this.voxels[id + 1] && (i == this.I - 1 || !this.voxels[id + 1 + this.JK])) {
                  this.exposuresBuffer[id][1] += smoothFactor * this.exposures[(id + 1)][1];
                  w += smoothFactor;
                }
              }

              this.exposuresBuffer[id][1] /= w;

              w = 1.0;
              if (j == 0 || !this.voxels[id - this.K]) {// bottom side open

                if (i > 0 && this.voxels[id - this.JK] && (j == 0 || !this.voxels[id - this.JK - this.K])) {
                  this.exposuresBuffer[id][2] += smoothFactor * this.exposures[(id - this.JK)][2];
                  w += smoothFactor;
                }
                if (i < this.I - 1 && this.voxels[id + this.JK] && (j == 0 || !this.voxels[id + this.JK - this.K])) {
                  this.exposuresBuffer[id][2] += smoothFactor * this.exposures[(id + this.JK)][2];
                  w += smoothFactor;
                }
                if (k > 0 && this.voxels[id - 1] && (j == 0 || !this.voxels[id - 1 - this.K])) {
                  this.exposuresBuffer[id][2] += smoothFactor * this.exposures[(id - 1)][2];
                  w += smoothFactor;
                }
                if (k < this.K - 1 && this.voxels[id + 1] && (j == 0 || !this.voxels[id + 1 - this.K])) {
                  this.exposuresBuffer[id][2] += smoothFactor * this.exposures[(id + 1)][2];
                  w += smoothFactor;
                }
              }
              this.exposuresBuffer[id][2] /= w;

              w = 1.0;
              if (j == this.J - 1 || !this.voxels[id + this.K]) {// top side open

                if (i > 0 && this.voxels[id - this.JK] && (j == this.J - 1 || !this.voxels[id - this.JK + this.K])) {
                  this.exposuresBuffer[id][3] += smoothFactor * this.exposures[(id - this.JK)][3];
                  w += smoothFactor;
                }
                if (i < this.I - 1 && this.voxels[id + this.JK] && (j == this.J - 1 || !this.voxels[id + this.JK + this.K])) {
                  this.exposuresBuffer[id][3] += smoothFactor * this.exposures[(id + this.JK)][3];
                  w += smoothFactor;
                }
                if (k > 0 && this.voxels[id - 1] && (j == this.J - 1 || !this.voxels[id - 1 + this.K])) {
                  this.exposuresBuffer[id][3] += smoothFactor * this.exposures[(id - 1)][3];
                  w += smoothFactor;
                }
                if (k < this.K - 1 && this.voxels[id + 1] && (j == this.J - 1 || !this.voxels[id + 1 + this.K])) {
                  this.exposuresBuffer[id][3] += smoothFactor * this.exposures[(id + 1)][3];
                  w += smoothFactor;
                }
              }
              this.exposuresBuffer[id][3] /= w;

              w = 1.0;
              if (k == 0 || !this.voxels[id - 1]) {// back open

                if (i > 0 && this.voxels[id - this.JK] && (k == 0 || !this.voxels[id - this.JK - 1])) {
                  this.exposuresBuffer[id][4] += smoothFactor * this.exposures[(id - this.JK)][4];
                  w += smoothFactor;
                }
                if (i < this.I - 1 && this.voxels[id + this.JK] && (k == 0 || !this.voxels[id + this.JK - 1])) {
                  this.exposuresBuffer[id][4] += smoothFactor * this.exposures[(id + this.JK)][4];
                  w += smoothFactor;
                }
                if (j > 0 && this.voxels[id - this.K] && (k == 0 || !this.voxels[id - this.K - 1])) {
                  this.exposuresBuffer[id][4] += smoothFactor * this.exposures[(id - this.K)][4];
                  w += smoothFactor;
                }
                if (j < this.J - 1 && this.voxels[id + this.K] && (k == 0 || !this.voxels[id + this.K - 1])) {
                  this.exposuresBuffer[id][4] += smoothFactor * this.exposures[(id + this.K)][4];
                  w += smoothFactor;
                }
              }
              this.exposuresBuffer[id][4] /= w;

              w = 1.0;
              if (k == this.K - 1 || !this.voxels[id + 1]) {// front open

                if (i > 0 && this.voxels[id - this.JK] && (k == this.K - 1 || !this.voxels[id - this.JK + 1])) {
                  this.exposuresBuffer[id][5] += smoothFactor * this.exposures[(id - this.JK)][5];
                  w += smoothFactor;
                }
                if (i < this.I - 1 && this.voxels[id + this.JK] && (k == this.K - 1 || !this.voxels[id + this.JK + 1])) {
                  this.exposuresBuffer[id][5] += smoothFactor * this.exposures[(id + this.JK)][5];
                  w += smoothFactor;
                }
                if (j > 0 && this.voxels[id - this.K] && (k == this.K - 1 || !this.voxels[id - this.K + 1])) {
                  this.exposuresBuffer[id][5] += smoothFactor * this.exposures[(id - this.K)][5];
                  w += smoothFactor;
                }
                if (j < this.J - 1 && this.voxels[id + this.K] && (k == this.K - 1 || !this.voxels[id + this.K + 1])) {
                  this.exposuresBuffer[id][5] += smoothFactor * this.exposures[(id + this.K)][5];
                  w += smoothFactor;
                }
              }
              this.exposuresBuffer[id][5] /= w;
            }

            id++;
          }
        }
      }
      tmp = this.exposures;
      this.exposures = this.exposuresBuffer;
      this.exposuresBuffer = tmp;
    }
  }
}

class IsoSystem {

  constructor(L, I, J, K) {
    this.L=L;
    this.I=I;
    this.J=J;
    this.K=K;
    this.IJK=I*J*K;
    this.voxelGrid=new VoxelGrid(I, J, K);
    this.hexGrid=new IsoHexGrid(this.L);
  }

  mapVoxelsToHexGrid() {
    this.hexGrid=new IsoHexGrid(this.L);
    let id=0;
    for (let i = 0; i < this.I; i++) {
      for (let j = 0; j < this.J; j++) {
        for (let k = 0; k < this.K; k++) {
          if (this.voxelGrid.get(id)) {
            this.hexGrid.addVoxel(i, j, k, this.voxelGrid.col(id));
          }
          id++;
        }
      }
    }
    this.voxelGrid.labelParts();
    this.hexGrid.setParts(this.voxelGrid);
    this.hexGrid.setRegions();
    this.hexGrid.collectLines();
    this.voxelGrid.setMaxAccessibilityAtBoundaries(16);
    this.voxelGrid.scanInteriorCubes(16);/*
    this.voxelGrid.calculateExposure(di, dj, dk);
    this.voxelGrid.diffuseExposure(0.12, 8);
    this.voxelGrid.smoothExposure(0.5, 4);
    this.hexGrid.setExposure(this.voxelGrid);*/
  }

  drawPoint( q, r) {
    let pt = this.hexGrid.getGridCoordinates(q, r);
    point(pt[0], pt[1]);
  }



  drawLine( q1, r1, q2, r2) {
    let point1 = this.hexGrid.getGridCoordinates(q1, r1);
    let point2 = this.hexGrid.getGridCoordinates(q2, r2);
    line(point1[0], point1[1], point2[0], point2[1]);
  }

  drawHex( q, r) {
    let center = this.hexGrid.getGridCoordinates(q, r);
    beginShape();
    for (let i = 0; i < 6; i++) {
      this.hexGrid.hexVertex(i, center);
    }
    endShape();
  }

  drawTriangle(q, r, f) {
    let center = this.hexGrid.getGridCoordinates(q, r);
    beginShape();
    this.hexGrid.triVertices(f, center);
    endShape();
  }

  drawTriangles() {
    let center;
    let cell;
    let sat;
    let bri;
    let hue;
    for (let key in this.hexGrid.cells) {
      cell=this.hexGrid.cells[key];
      center = this.hexGrid.getGridCoordinates(cell.q, cell.r);
      for (let f = 0; f < 6; f++) {
        if (cell.getOrientation(f) > -1) {
          beginShape();
          sat=(cell.i[f]==lI-1 || cell.k[f]==lK-1)?0:255;
          bri=(cell.i[f]==lI-1 || cell.k[f]==lK-1)?64+cell.orientation[f]*100:cell.exposures[f][2*cell.orientation[f]+1]*16;
          hue=(cell.i[f]==lI-1 || cell.k[f]==lK-1)?(lastFrame/170)%360:(lastFrame/170+(cell.part[f]*13)%100+5*cell.orientation[f])%360;
          stroke(hue, sat, bri);
          fill(hue, sat, bri);
          this.hexGrid.triVertices(f, center);
          endShape();
        }
      }
    }
  }

  drawLines() {
    let line;
    let segment;

    for (let i=0; i<this.hexGrid.lines.length; i++) {
      line=this.hexGrid.lines[i];
      for (let j=0; j<line.segments.length; j++) {
        segment=line.segments[j];
        this.drawLine(segment.q1, segment.r1, segment.q2, segment.r2);
      }
    }
  }

  drawOutlines() {
    let line;
    let segment;
    for (let i=0; i<this.hexGrid.outlines.length; i++) {
      line=this.hexGrid.outlines[i];
      for (let j=0; j<line.segments.length; j++) {
        segment=line.segments[j];
        this.drawLine(segment.q1, segment.r1, segment.q2, segment.r2);
      }
    }
  }
}



function code3x3(c) {
  /*
     * 1 | 2 | 4
   * 8 | 16 | 32
   * 64 | 128 | 256
   */
  switch (c) {
  case 'a':
    return 378;
  case 'b':
    return 251;
  case 'c':
    return 463;
  case 'd':
    return 235;
  case 'e':
    return 479;
  case 'f':
    return 95;
  case 'g':
    return 507;
  case 'h':
    return 381;
  case 'i':
    return 471;
  case 'j':
    return 230;
  case 'k':
    return 349;
  case 'l':
    return 457;
  case 'm':
    return 383;
  case 'n':
    return 363;
  case 'o':
    return 495;
  case 'p':
    return 127;
  case 'q':
    return 426;
  case 'r':
    return 347;
  case 's':
    return 214;
  case 't':
    return 151;
  case 'u':
    return 493;
  case 'v':
    return 173;
  case 'w':
    return 509;
  case 'x':
    return 341;
  case 'y':
    return 149;
  case 'z':
    return 403;
  case '0':
    return 495;
  case '1':
    return 467;
  case '2':
    return 403;
  case '3':
    return 503;
  case '4':
    return 317;
  case '5':
    return 214;
  case '6':
    return 505;
  case '7':
    return 295;
  case '8':
    return 511;
  case '9':
    return 319;
  case '-':
    return 56;
  case '.':
    return 192;
  case ',':
    return 72;
  case ':':
    return 65;
  case ';':
    return 193;
  case '\'':
    return 9;
  case '\"':
    return 3;
  case '!':
    return 73;
  case '?':
    return 91;
  case '(':
    return 138;
  case ')':
    return 162;
  default:
    return 0;
  }
}



function getChar3x3( c, flipX, flipY) {
  let id=0;
  let code = code3x3(c);
  let grid = [];
  for (let i = 0; i < 3; i++) {
    grid[i]=[];
  }

  for (let j = 0; j < 3; j++) {
    for (let i = 0; i < 3; i++) {
      if (((code >> id) & 1) == 1) {

        grid[flipX?2-i:i][flipY?2-j:j] = 1;
      }
      id++;
    }
  }

  return grid;
}
