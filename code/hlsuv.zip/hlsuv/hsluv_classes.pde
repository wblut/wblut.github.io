//Direct port of the hsluv haxe reference implementation: https://github.com/hsluv/hsluv
//Original license
//Copyright (c) 2012-2020 Alexei Boronine
//Copyright (c) 2016 Florian Dormont

//Permission is hereby granted, free of charge, to any person obtaining a copy
//of this software and associated documentation files (the "Software"), to deal
//in the Software without restriction, including without limitation the rights
//to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//copies of the Software, and to permit persons to whom the Software is
//furnished to do so, subject to the following conditions:

//The above copyright notice and this permission notice shall be included in all
//copies or substantial portions of the Software.

//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//SOFTWARE.


class  HSLUVLine {
  double slope;
  double intercept;
  HSLUVLine(double slope, double intercept) {
    this.slope=slope;
    this.intercept=intercept;
  }
}

class HSLUVPoint {
  double x;
  double y;

  HSLUVPoint(double x, double y) {
    this.x=x;
    this.y=y;
  }
}

HSLUVPoint intersectLineLine( HSLUVLine a, HSLUVLine b) {
  double x = (a.intercept - b.intercept) / (b.slope - a.slope);
  double y = a.slope * x + a.intercept;
  return new  HSLUVPoint(x, y);
}

double distanceFromOrigin( HSLUVPoint point) {
  return Math.sqrt(Math.pow(point.x,2) + Math.pow(point.y,2));
}

double distanceLineFromOrigin( HSLUVLine line) {
  return Math.abs(line.intercept) / Math.sqrt(Math.pow(line.slope,2) + 1);
}

HSLUVLine perpendicularThroughPoint( HSLUVLine line, HSLUVPoint point) {
  double slope = -1 / line.slope;
  double intercept = point.y - slope * point.x;
  return new  HSLUVLine(slope, intercept);
}

double angleFromOrigin( HSLUVPoint point) {
  return Math.atan2(point.y, point.x);
}

double normalizeAngle(double angle) {
  return ((angle % TWO_PI) + TWO_PI) % TWO_PI;
}

double lengthOfRayUntilIntersect(double theta, HSLUVLine line) {
  /*
        theta  -- angle of ray starting at (0, 0)
   m, b   -- slope and intercept of line
   x1, y1 -- coordinates of intersection
   len    -- length of ray until it intersects with line
   
   b + m * x1        = y1
   len              >= 0
   len * cos(theta)  = x1
   len * sin(theta)  = y1
   
   
   b + m * (len * cos(theta)) = len * sin(theta)
   b = len * sin(hrad) - m * len * cos(theta)
   b = len * (sin(hrad) - m * cos(hrad))
   len = b / (sin(hrad) - m * cos(hrad))
   */
  return line.intercept / (Math.sin(theta) - line.slope * Math.cos(theta));
}

double[][] m =new double[][]
  {
  {3.240969941904521, -1.537383177570093, -0.498610760293}, 
  {-0.96924363628087, 1.87596750150772, 0.041555057407175}, 
  {0.055630079696993, -0.20397695888897, 1.056971514242878}
};

double[][] minv =new double[][]
  {
  {0.41239079926595, 0.35758433938387, 0.18048078840183}, 
  {0.21263900587151, 0.71516867876775, 0.072192315360733}, 
  {0.019330818715591, 0.11919477979462, 0.95053215224966}
};

double refY = 1.0;

double refU = 0.19783000664283;
double refV = 0.46831999493879;

// CIE LUV constants
double kappa = 903.2962962;
double epsilon = 0.0088564516;

String hexChars = "0123456789abcdef";

/**
 For a given lightness, return a list of 6 lines in slope-intercept
 form that represent the bounds in CIELUV, stepping over which will
 push a value out of the RGB gamut
 */
ArrayList< HSLUVLine> getBounds(double L) {
  ArrayList< HSLUVLine> result=new ArrayList< HSLUVLine>(6);

  double sub1 = Math.pow(L + 16, 3) / 1560896;
  double sub2 = sub1 > epsilon ? sub1 : L / kappa;

  for (int c=0; c<3; c++) {
    double m1 = m[c][0];
    double m2 = m[c][1];
    double m3 = m[c][2];
    for (int t=0; t<2; t++) {
      double top1 = (284517 * m1 - 94839 * m3) * sub2;
      double top2 = (838422 * m3 + 769860 * m2 + 731718 * m1) * L * sub2 - 769860 * t * L;
      double bottom = (632260 * m3 - 126452 * m2) * sub2 + 126452 * t;
      result.add(new  HSLUVLine( top1 / bottom, top2 / bottom));
    }
  }

  return result;
}

/**
 For given lightness, returns the maximum chroma. Keeping the chroma value
 below this number will ensure that for any hue, the color is within the RGB
 gamut.
 */
double maxSafeChromaForL(double L) {
  ArrayList< HSLUVLine> bounds = getBounds(L);
  double min = Float.POSITIVE_INFINITY;

  for ( HSLUVLine bound : bounds) {
    double length = distanceLineFromOrigin(bound);
    min = Math.min(min, length);
  }
  return min;
}

double maxChromaForLH(double L, double H) {
  double hrad = H / 360 * TWO_PI;
  ArrayList< HSLUVLine> bounds = getBounds(L);
  double min = Float.POSITIVE_INFINITY;

  for ( HSLUVLine bound : bounds) {
    double length =lengthOfRayUntilIntersect(hrad, bound);
    if (length >= 0) {
      min = Math.min(min, length);
    }
  }

  return min;
}

double dotProduct(double[] a, double[] b) {
  double sum = 0;

  for (int i=0; i<a.length; i++) {
    sum += a[i] * b[i];
  }

  return sum;
}

// Used for rgb conversions
double fromLinear(double c) {
  if (c <= 0.0031308) {
    return 12.92 * c;
  } else {
    return 1.055 * Math.pow(c, 1 / 2.4) - 0.055;
  }
}

double toLinear(double c) {
  if (c > 0.04045) {
    return Math.pow((c + 0.055) / (1 + 0.055), 2.4);
  } else {
    return c / 12.92;
  }
}

/**
 * XYZ coordinates are ranging in [0;1] and RGB coordinates in [0;255] range.
 * @param tuple An array containing the color's X,Y and Z values.
 * @return An array containing the resulting color's red, green and blue.
 **/
color xyzToRgb(double... tuple) {
  return color(
    (float)(255*fromLinear(dotProduct(m[0], tuple))), 
    (float)(255*fromLinear(dotProduct(m[1], tuple))), 
    (float)(255*fromLinear(dotProduct(m[2], tuple)))
    );
}

/**
 * RGB coordinates are ranging in [0;255] and XYZ coordinates in [0;1].
 * @param tuple An array containing the color's R,G,B values.
 * @return An array containing the resulting color's XYZ coordinates.
 **/
double[] rgbToXyz(color tuple) {
  double[]  rgbl=new double[]{

    toLinear(red(tuple)/255.0), 
    toLinear(green(tuple)/255.0), 
    toLinear(blue(tuple)/2550.)
  };

  return new double[]{
    dotProduct(minv[0], rgbl), 
    dotProduct(minv[1], rgbl), 
    dotProduct(minv[2], rgbl)
  };
}

/*
 http://en.wikipedia.org/wiki/CIELUV
 In these formulas, Yn refers to the reference white point. We are using
 illuminant D65, so Yn (see refY in Maxima file) equals 1. The formula is
 simplified accordingly.
 */
double yToL(double Y) {
  if (Y <= epsilon) {
    return (Y / refY) * kappa;
  } else {
    return 116 * Math.pow(Y / refY, 1.0 / 3.0) - 16;
  }
}

double lToY(double L) {
  if (L <= 8) {
    return refY * L / kappa;
  } else {
    return refY * Math.pow((L + 16) / 116, 3);
  }
}

/**
 * XYZ coordinates are ranging in [0;1].
 * @param tuple An array containing the color's X,Y,Z values.
 * @return An array containing the resulting color's LUV coordinates.
 **/
double[] xyzToLuv(double... tuple) {
  double X = tuple[0];
  double Y = tuple[1];
  double Z = tuple[2];

  // This divider fix avoids a crash on Python (divide by zero except.)
  double divider = (X + (15 * Y) + (3 * Z));
  double varU = 4 * X;
  double varV = 9 * Y;

  varU /= divider;
  varV /= divider;

  double L = yToL(Y);

  if (L == 0) {
    return new double[]{0, 0, 0};
  }

  double U = 13 * L * (varU - refU);
  double V = 13 * L * (varV - refV);

  return new double[]{L, U, V};
}

/**
 * XYZ coordinates are ranging in [0;1].
 * @param tuple An array containing the color's L,U,V values.
 * @return An array containing the resulting color's XYZ coordinates.
 **/
double[] luvToXyz(double... tuple) {
  double L = tuple[0];
  double U= tuple[1];
  double V= tuple[2];

  if (L == 0) {
    return new double[]{0, 0, 0};
  }

  double varU= U / (13 * L) + refU;
  double varV= V / (13 * L) + refV;

  double Y = lToY(L);
  double X= 0 - (9 * Y * varU) / ((varU - 4) * varV - varU * varV);
  double Z= (9 * Y - (15 * varV * Y) - (varV * X)) / (3 * varV);

  return new double[]{X, Y, Z};
}

/**
 * @param tuple An array containing the color's L,U,V values.
 * @return An array containing the resulting color's LCH coordinates.
 **/
double[] luvToLch(double... tuple) {
  double L = tuple[0];
  double U = tuple[1];
  double V= tuple[2];

  double C= Math.sqrt(U * U + V * V);
  double H;

  // Greys: disambiguate hue
  if (C < 0.00000001) {
    H = 0;
  } else {
    double Hrad = Math.atan2(V, U);
    H = (Hrad * 180.0) / PI;

    if (H < 0) {
      H = 360 + H;
    }
  }

  return new double[]{L, C, H};
}

/**
 * @param tuple An array containing the color's L,C,H values.
 * @return An array containing the resulting color's LUV coordinates.
 **/
double[] lchToLuv(double... tuple) {
  double L = tuple[0];
  double C = tuple[1];
  double H = tuple[2];

  double Hrad = H / 360.0 * 2 *PI;
  double U = Math.cos(Hrad) * C;
  double V = Math.sin(Hrad) * C;

  return new double[]{L, U, V};
}

/**
 * HSLuv values are ranging in [0;360], [0;100] and [0;100].
 * @param tuple An array containing the color's H,S,L values in HSLuv color space.
 * @return An array containing the resulting color's LCH coordinates.
 **/
double[] hsluvToLch(double... tuple) {
  double H = tuple[0];
  double S = tuple[1];
  double L = tuple[2];

  // White and black: disambiguate chroma
  if (L > 99.9999999) {
    return new double[]{100, 0, H};
  }

  if (L < 0.00000001) {
    return new double[]{0, 0, H};
  }

  double max = maxChromaForLH(L, H);
  double C = max / 100 * S;

  return new double[]{L, C, H};
}

/**
 * HSLuv values are ranging in [0;360], [0;100] and [0;100].
 * @param tuple An array containing the color's LCH values.
 * @return An array containing the resulting color's HSL coordinates in HSLuv color space.
 **/
double[] lchToHsluv(double... tuple) {
  double L = tuple[0];
  double C = tuple[1];
  double H = tuple[2];

  // White and black: disambiguate chroma
  if (L > 99.9999999) {
    return new double[]{H, 0, 100};
  }

  if (L < 0.00000001) {
    return new double[]{H, 0, 0};
  }

  double max= maxChromaForLH(L, H);
  double S = C / max * 100;

  return new double[]{H, S, L};
}

/**
 * HSLuv values are in [0;360], [0;100] and [0;100].
 * @param tuple An array containing the color's H,S,L values in HPLuv (pastel variant) color space.
 * @return An array containing the resulting color's LCH coordinates.
 **/
double[] hpluvToLch(double... tuple) {
  double H= tuple[0];
  double S = tuple[1];
  double L= tuple[2];

  if (L > 99.9999999) {
    return new double[]{100, 0, H};
  }

  if (L < 0.00000001) {
    return new double[]{0, 0, H};
  }

  double max = maxSafeChromaForL(L);
  double C = max / 100 * S;

  return new double[]{L, C, H};
}

/**
 * HSLuv values are ranging in [0;360], [0;100] and [0;100].
 * @param tuple An array containing the color's LCH values.
 * @return An array containing the resulting color's HSL coordinates in HPLuv (pastel variant) color space.
 **/
double[] lchToHpluv(double... tuple) {
  double L = tuple[0];
  double C= tuple[1];
  double H= tuple[2];

  // White and black: disambiguate saturation
  if (L > 99.9999999) {
    return new double[]{H, 0, 100};
  }

  if (L < 0.00000001) {
    return new double[]{H, 0, 0};
  }

  double max = maxSafeChromaForL(L);
  double S = C / max * 100;

  return new double[]{H, S, L};
}




/**
 * RGB values are ranging in [0;255].
 * @param tuple An array containing the color's LCH values.
 * @return An array containing the resulting color's RGB coordinates.
 **/
color lchToRgb(double... tuple) {
  return xyzToRgb(luvToXyz(lchToLuv(tuple)));
}

/**
 * RGB values are ranging in [0;255].
 * @param tuple An array containing the color's RGB values.
 * @return An array containing the resulting color's LCH coordinates.
 **/
double[]rgbToLch(color tuple) {
  return luvToLch(xyzToLuv(rgbToXyz(tuple)));
}

// RGB <--> HPLuv

/**
 * HSLuv values are ranging in [0;360], [0;100] and [0;100] and RGB in [0;255].
 * @param tuple An array containing the color's HSL values in HSLuv color space.
 * @return An array containing the resulting color's RGB coordinates.
 **/

color hsluvToRgb(double... tuple) {
  return lchToRgb(hsluvToLch(tuple));
}

/**
 * HSLuv values are ranging in [0;360], [0;100] and [0;100] and RGB in [0;255].
 * @param tuple An array containing the color's RGB coordinates.
 * @return An array containing the resulting color's HSL coordinates in HSLuv color space.
 **/

double[] rgbToHsluv(color tuple) {
  return lchToHsluv(rgbToLch(tuple));
}

/**
 * HSLuv values are ranging in [0;360], [0;100] and [0;100] and RGB in [0;255].
 * @param tuple An array containing the color's HSL values in HPLuv (pastel variant) color space.
 * @return An array containing the resulting color's RGB coordinates.
 **/

color hpluvToRgb(double... tuple) {
  return lchToRgb(hpluvToLch(tuple));
}

/**
 * HSLuv values are ranging in [0;360], [0;100] and [0;100] and RGB in [0;255].
 * @param tuple An array containing the color's RGB coordinates.
 * @return An array containing the resulting color's HSL coordinates in HPLuv (pastel variant) color space.
 **/
double[] rgbToHpluv(color tuple) {
  return lchToHpluv(rgbToLch(tuple));
}
