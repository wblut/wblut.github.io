
void setup() {
  size(400, 300);
}

void draw() {
  background(0);
  noStroke();

  colorMode(HSB);
  for (int i = 0; i < 10; i++) {
    fill(map(i,0,18,0,255), map(mouseX,0,width,0,255), map(mouseY,0,height,0,255));
    rect(i * 40, 0, 40, 40);
  }

  colorMode(RGB);
  translate(0, 40);
  for (int i = 0; i < 10; i++) {
    fill(hsluvToRgb(i * 20, map(mouseX,0,width,0,100), map(mouseY,0,height,0,100)));
    rect(i * 40, 0, 40, height-40);
  }
}
