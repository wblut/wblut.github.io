//Buffers for the frame averaging
float[] r;
float[] g;
float[] b;
//Camera settings
float fov;
float camz;
//Number of samples to average
int samples;

void setup() {
  fullScreen(P3D);
  smooth(8);
  noCursor();
  r=new float[width*height];
  g=new float[width*height];
  b=new float[width*height];
  //default camera settings
  fov=radians(60);
  camz=height/2/tan(0.5*fov);

  samples=256;
}

//Initialize the buffers
void initRGB() {
  for (int i=0; i<width*height; i++) {
    r[i]=0;
    g[i]=0;
    b[i]=0;
  }
}

//First draw the samples, when complete draw the average
void draw() {
  if (frameCount<=samples) {
    pushMatrix();
    drawSample();
    popMatrix();
    loadPixels();
    for (int i=0; i<pixels.length; i++) {
      r[i] += (pixels[i] >> 16 & 0xff);
      g[i] += (pixels[i] >> 8 & 0xff);
      b[i] += (pixels[i] & 0xff);
    }
    fill(0);
    textSize(20);
    text("sample "+frameCount+" of "+samples, 50, height-50);
  } else {
    loadPixels();
    for (int i=0; i<pixels.length; i++) {
      pixels[i] = 0xff << 24 | 
        int(r[i]/samples) << 16 | 
        int(g[i]/samples) << 8 | 
        int(b[i]/samples);
    }
    updatePixels();
    text("press spacebar to reset", 50, height-50);
    noLoop();
  }
}

//Draw a single sample
void drawSample() {
  background(55);
  sampleCameraInDisk(1.7,20.0);//first parameter tunes depth of focus (trial and error, 1.0-2.4 seems to work for this image), second parameter is radius of disk
  drawThing();
}

//Pick a random camera position in a disk with radius rcentered on the Z-axis,aimed at (0,0,0)
void sampleCameraInDisk(float focus, float radius) {

  float r = radius*sqrt(random(1.0));
  float t = random(TWO_PI);
  camera(r * cos(t), r * sin(t), camz, r * cos(t), r * sin(t), 0, 0, 1, 0);
  float f=camz/10.0 * (float) Math.tan(fov / 2);
  float ymax = f;
  float ymin = -f;
  float xmin = -f * width/float(height);
  float xmax = f * width/float(height);
  float offsetx=focus*r * cos(t)*f/camz;
  float offsety=focus*r * sin(t)*f/camz;
  frustum(xmin-offsetx, xmax-offsetx, ymin+offsety, ymax+offsety, camz/10.0, camz*10.0);
}




void drawThing() {

  for (int i=-20; i<=20; i++) {
    for (int j=-20; j<=20; j++) {
      fill(128+12*i, 128-12*j, 2.4*i*j);
      pushMatrix();
      translate(40*i, 40*j, 4*i*j);
      box(10);
      popMatrix();
    }
  }
}

void keyPressed() {
  if (key==' ') {
    frameCount=0;
    initRGB();
    loop();
  }
}
