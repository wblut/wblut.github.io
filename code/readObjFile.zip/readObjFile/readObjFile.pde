BufferedReader reader;
String line;

void setup() {  
  readFile("pyramid.obj");
}

void readFile(String file) {
  reader = createReader(file);
  do {
    try {
      line = reader.readLine();
    } 
    catch (IOException e) {
      e.printStackTrace();
      line = null;
    }
    if (line == null) {
      return;
    } else {
      println(line);
    }
  } while (true);
}
