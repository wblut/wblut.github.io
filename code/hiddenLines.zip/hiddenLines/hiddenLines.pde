import processing.svg.*;
import wblut.math.*;
import wblut.processing.*;
import wblut.core.*;
import wblut.hemesh.*;
import wblut.geom.*;

WB_Render render;
WB_Point target;
WB_Point eye;
WB_Vector eyeDirection;
WB_Plane imagePlane;

HE_Mesh mesh;
WB_AABBTree3D tree;

HE_ObjectMap<WB_List<WB_Segment>> segments;
HE_ObjectMap<WB_List<WB_Segment>> projectedSegments;
boolean includeOutline;
boolean drawSVG;

void setup() {
  fullScreen(P3D);
  smooth(8);
  noCursor();
  render=new WB_Render(this);
  target=new WB_Point();
  eyeDirection=new WB_Point(0.1, -0.2,-1.0);
  eye=target.addMul(-800,eyeDirection);  
  imagePlane=new WB_Plane(target.addMul(400.0, eyeDirection), eyeDirection);  
  includeOutline=true; 
  createMesh();
  createContours();  
  findVisibleSegments(mesh, 0.1);
}

void draw() {
  background(55);
  directionalLight(255, 255, 255, 1, 1, -1);
  directionalLight(127, 127, 127, -1, -1, 1);
  translate(width/2, height/2);
  rotateY(mouseX*1.0f/width*TWO_PI);
  rotateX(mouseY*1.0f/height*TWO_PI);
  noStroke();
  render.drawFaces(mesh);
  stroke(0);
  render.drawEdges(mesh);
  strokeWeight(1);
  stroke(0, 255, 0);
  for (HE_Halfedge e :  mesh.getEdges()) {
    WB_List<WB_Segment> segs = segments.get(e); 
    segs = projectedSegments.get(e); 
    if (segs!=null) {
      for (WB_Segment seg : segs) {
        render.drawSegment(seg);
      }
    }
    segs = segments.get(e); 
    if (segs!=null) {
      for (WB_Segment seg : segs) {
        render.drawSegment(seg);
      }
    }
  }
  for (HE_Halfedge e :  mesh.getEdges()) {
    WB_List<WB_Segment> segs = segments.get(e); 
    if (segs!=null) 
      for (WB_Segment seg : segs) {
        beginShape(LINES);
        stroke(0, 255, 0, 80);
        vertex(eye.xf(), eye.yf(), eye.zf());
        stroke(0, 255, 0, 0);
        vertex(seg.getOrigin().xf(), seg.getOrigin().yf(), seg.getOrigin().zf());
        endShape();
        beginShape(LINES);
        stroke(0, 255, 0, 80);
        vertex(eye.xf(), eye.yf(), eye.zf());
        stroke(0, 255, 0, 0);
        vertex(seg.getEndpoint().xf(), seg.getEndpoint().yf(), seg.getEndpoint().zf());
        endShape();
      }
  }

  if (drawSVG) {
    background(255); 
    beginRecord(SVG, "/export/export.svg"); 
    stroke(0); 
    for (HE_Halfedge e :  mesh.getEdges()) {
      strokeWeight(1);
      WB_List<WB_Segment> segs = projectedSegments.get(e); 
      if (segs!=null) {
        for (WB_Segment seg : segs) {
          projectedLine(seg.getOrigin(), seg.getEndpoint());
        }
      }
    }
    endRecord(); 
    drawSVG = false;
  }
}

void keyPressed() {
  if (key=='s') drawSVG=true;
}
