void findVisibleSegments(HE_Mesh mesh, double step) {
  segments=new HE_ObjectMap<WB_List<WB_Segment>>();
  projectedSegments=new HE_ObjectMap<WB_List<WB_Segment>>();
  
  mesh.clearVisitedElements();
  
  tree=new WB_AABBTree3D(mesh, 1);
  tree.expandBy(1.0);
  HE_Face f;
  HE_FaceIterator fItr=mesh.fItr();
  HE_Halfedge edge; 
  WB_Vector v; 
  WB_Point p;
  HE_FaceEdgeCirculator feCrc;
  WB_Coord p1=null;
  WB_Coord p2=null;
  double l;
  boolean current;
  boolean previous;
  int fid=0;
  while (fItr.hasNext()) {
    println("Checking face: "+(fid++)+" of "+mesh.getNumberOfFaces());
    f=fItr.next();
    feCrc=f.feCrc();
    while (feCrc.hasNext()) {
      edge=feCrc.next();
      if (!edge.isVisited()&&edge.isVisible()) {
        WB_List<WB_Segment> edgeSegments=new WB_List<WB_Segment>();
        WB_List<WB_Segment> edgeProjectedSegments=new WB_List<WB_Segment>();
        v=edge.getEdgeDirection();
        l=edge.getLength();
        current=false;
        previous=false;
        for (double dl=0.0; dl<l; dl+=step) {
          p=WB_Point.addMul( edge.getStartVertex(), dl, v);
          current=isVisible(p, eye, tree, 0.001);
          if (current!=previous) {
            if (current) {
              p1=p;
            } else {
              p2=p;
              if (WB_Point.getDistance3D(p1, p2)>=Math.min(l, 2*step)) {
                edgeSegments.add(new WB_Segment(p1, p2));
                edgeProjectedSegments.add(getProjectedSegment(new WB_Segment(p1, p2)));
              }
            }
          }
          previous=current;
        }
        if (current && WB_Point.getDistance3D(p1, edge.getEndVertex())>=Math.min(l, 2*step)) {
          edgeSegments.add(new WB_Segment(p1, edge.getEndVertex()));
          edgeProjectedSegments.add(getProjectedSegment(new WB_Segment(p1, edge.getEndVertex())));
        }
        edge.setVisited();
        segments.put(edge, edgeSegments);
        projectedSegments.put(edge, edgeProjectedSegments);
      }
    }
  }
}

boolean isVisible(WB_Coord p, WB_Coord eye, WB_AABBTree3D tree, double sqThreshold) {
  WB_Ray ray=new WB_Ray(eye, new WB_Vector(eye, p)); 
  HE_MeshOp.HE_FaceLineIntersection fli=HE_MeshOp.getClosestIntersection(tree, ray); 
  return (fli==null)||fli.getPoint().getSqDistance3D(p)<sqThreshold;
}
