void createMesh() {  
  mesh=new HE_Mesh(new HEC_FromOBJFile().setPath(sketchPath("/data/teddy.obj")));
  mesh.fitInAABBConstrained(new WB_AABB(-300,-300,-300,300,300,300));
  mesh.triangulate();
}
