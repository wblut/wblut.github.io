void createContours() {
  mesh.addFloatAttribute("level", 1000.0, true);
  HE_VertexIterator vItr=mesh.vItr();
  HE_Vertex v;
  while (vItr.hasNext()) {
    v=vItr.next();
    mesh.setFloatAttribute(v, "level", v.yf());//contouring function
  }

  mesh.getNewSelection("contours");
  for (int i=-400; i<=400; i+=10) {
    println("Creating contours level (-400,400): "+i);
    mesh.modify(new HEM_Contours().setAttribute("level").setLevel(i));
    mesh.getSelection("contours").addHalfedges(mesh.getSelection("splitEdges"));
  }

  HE_HalfedgeIterator heItr=mesh.heItr();
  HE_Halfedge he;
  while (heItr.hasNext()) {
    he=heItr.next();
   if(!(isOutline(he)&&includeOutline)) he.clearVisible();
  }
  
  heItr= mesh.getSelection("contours").heItr();
  while (heItr.hasNext()) {
    heItr.next().setVisible();
  }
}
