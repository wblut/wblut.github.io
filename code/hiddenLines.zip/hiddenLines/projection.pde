WB_Segment getProjectedSegment(WB_Segment seg) {
  WB_Ray ray1, ray2;
  WB_IntersectionResult ir;
  WB_Coord p1, p2;
  p1=seg.getOrigin(); 
  p2=seg.getEndpoint();
  ray1=new WB_Ray(eye, new WB_Vector(eye, p1));
  ray2=new WB_Ray(eye, new WB_Vector(eye, p2));
  ir=WB_GeometryOp3D.getIntersection3D(ray1, imagePlane);
  if (ir==null) return null;
  p1=(WB_Point)(ir.getObject());
  if (p1==null) return null;
  ir=WB_GeometryOp3D.getIntersection3D(ray2, imagePlane);
  if (ir==null) return null;
  p2=(WB_Point)(ir.getObject());
  if (p2==null) return null;
  return new WB_Segment(p1, p2);
}

void projectedLine(WB_Coord p, WB_Coord q) {
  p=imagePlane.localPoint2D(p);
  q=imagePlane.localPoint2D(q);
  line(p.xf(), p.yf(), q.xf(), q.yf());
}

boolean isOutline(HE_Halfedge e) {
  if (e.getFace()==null) return true;
  if (e.getPair().getFace()==null) return true;
  WB_Coord ec=e.getCenter();
  WB_Vector v=new WB_Vector(eye,ec);
  v.normalizeSelf();
  if((v.dot(e.getFace().getFaceNormal())*v.dot(e.getPair().getFace().getFaceNormal()))<WB_Epsilon.EPSILON) return true;
  return false;
}
