MVC meanValueCoordinates;
int numPoints;
float[][] points;
float[] pointHues;
int[][] triangles;
float[][] values;
Wanderer[] wanderers;
PImage sprite;

void setup() {
  fullScreen(P3D);
  smooth(8);
  noCursor();
  imageMode(CENTER);
  createSprite();
  createMesh();
  createWanderers();
}

void createSprite() {
  int maxSpriteSize=256;
  int minSpriteSize=8;
  float glowKernelWidth=0.8f;// glow core size parameter
  float glowKernelDecayPower=2.0f;// glow core decay power (~1.4-3.6)
  int reqGlowKernelSize =constrain(5*(int)pow(100f*glowKernelWidth, 1f/glowKernelDecayPower), minSpriteSize, maxSpriteSize);// required image size to accomodate the glow kernel
  int half=reqGlowKernelSize/2;
  reqGlowKernelSize=2*half;
  sprite=createImage(reqGlowKernelSize, reqGlowKernelSize, RGB);
  float r2, brightness;
  for (int i=0; i <  reqGlowKernelSize; i++) {
    for (int j=0; j <  reqGlowKernelSize; j++) {
      r2=(i-half)*(i-half)+(j-half)*(j-half);
      brightness=255.999999f*glowKernelWidth/(glowKernelWidth+pow(r2, 0.5*glowKernelDecayPower));// radial symmetric decreasing function
      sprite.pixels[i+reqGlowKernelSize*j] = color(brightness, brightness);
    }
  }
}

void createMesh() {
  //ICOSAHEDRON
  numPoints=12;
  points=new float[][] { { 0., 0., -0.951057 }, { 0., 0., 0.951057 }, { -0.850651, 0., -0.425325 }, { 0.850651, 0., 0.425325 }, 
    { 0.688191, -0.5, -0.425325 }, { 0.688191, 0.5, -0.425325 }, { -0.688191, -0.5, 0.425325 }, 
    { -0.688191, 0.5, 0.425325 }, { -0.262866, -0.809017, -0.425325 }, 
    { -0.262866, 0.809017, -0.425325 }, { 0.262866, -0.809017, 0.425325 }, 
    { 0.262866, 0.809017, 0.425325 } };

  for (int i=0; i<numPoints; i++) {
    for (int j=0; j<3; j++) {
      points[i][j]*=200.0;
    }
  }

  values=new float[numPoints][6];
  for (int i=0; i<numPoints; i++) {
    values[i][0]=random(-1.0, 1.0);
    values[i][1]=random(-1.0, 1.0);
    values[i][2]=random(-1.0, 1.0);
    values[i][3]=random(256);
    values[i][4]=random(256);
    values[i][5]=random(256);
  }

  triangles=new int[][]{ { 1, 11, 7 }, { 1, 7, 6 }, { 1, 6, 10 }, { 1, 10, 3 }, { 1, 3, 11 }, { 4, 8, 0 }, { 5, 4, 0 }, 
    { 9, 5, 0 }, { 2, 9, 0 }, { 8, 2, 0 }, { 11, 9, 7 }, { 7, 2, 6 }, { 6, 8, 10 }, { 10, 4, 3 }, 
    { 3, 5, 11 }, { 4, 10, 8 }, { 5, 3, 4 }, { 9, 11, 5 }, { 2, 7, 9 }, { 8, 6, 2 } };

  meanValueCoordinates=new MVC(values, points, triangles);
}

void createWanderers() {
  int numWanderers=10000;
  wanderers=new Wanderer[numWanderers];
  for (int i=0; i<numWanderers; i++) {
    wanderers[i]=new Wanderer();
  }
  getWandererValues(1);
}

void getWandererValues(int inc) {
  for (int w=(frameCount%inc); w<wanderers.length; w+=inc) {
    wanderers[w].setValues(meanValueCoordinates.getValues(wanderers[w].x, wanderers[w].y, wanderers[w].z));
  }
}

void draw() {
  hint(ENABLE_DEPTH_MASK);
  blendMode(BLEND);
  background(0);
  getWandererValues(10); 
  translate(width/2, height/2);
  drawMesh();
  rotateMesh();
  hint(DISABLE_DEPTH_MASK);
  blendMode(ADD);
  drawWanderers();
  updateWanderers(2.0);
}

void drawMesh() {
  strokeWeight(1.0);
  stroke(255);
  noFill();
  int vi, vj;

  for (int[] triangle : triangles) {
    beginShape(LINES);
    for (int i=0, j=2; i<3; j=i, i++) {
      vj=triangle[j];
      vi=triangle[i];
      if (vi<vj) {
        stroke(values[vj][3], values[vj][4], values[vj][5]);
        vertex(points[vj][0], points[vj][1], points[vj][2]);
        stroke(values[vi][3], values[vi][4], values[vi][5]);
        vertex(points[vi][0], points[vi][1], points[vi][2]);
      }
    }
    endShape();
  }
}


void updateWanderers(float dt) {
  for (Wanderer w : wanderers) {
    w.update(dt*w.values[0], dt*w.values[1], dt*w.values[2]);
  }
}

void drawWanderers() {
  noStroke();
  for (Wanderer w : wanderers) {
    w.draw();
  }
}



//https://sites.google.com/site/glennmurray/Home/rotation-matrices-and-formulas/rotation-about-an-arbitrary-axis-in-3-dimensions
void rotateMesh() {
  float u, v, w;
  u=v=w=1.0/sqrt(3.0);
  float theta=radians(0.5);
  float ct=cos(theta);
  float st=sin(theta);
  float x, y;
  float uxvywz;
  for (float[] point : points) {
    uxvywz=u*point[0]+v*point[1]+w*point[2];
    x=u*uxvywz*(1.0-ct)+point[0]*ct+(v*point[2]-w*point[1])*st;
    y=v*uxvywz*(1.0-ct)+point[1]*ct+(w*point[0]-u*point[2])*st;
    point[2]=w*uxvywz*(1.0-ct)+point[2]*ct+(u*point[1]-v*point[0])*st;
    point[0]=x;
    point[1]=y;
  }
}

void mousePressed() {

  for (int i=0; i<numPoints; i++) {
    values[i][0]=random(-1.0, 1.0);
    values[i][1]=random(-1.0, 1.0);
    values[i][2]=random(-1.0, 1.0);
    values[i][3]=random(256);
    values[i][4]=random(256);
    values[i][5]=random(256);
  }
  createWanderers();
}



class Wanderer {
  float x, y, z;
  float[] values;
  Wanderer() {
    float eps =random(1.0);
    z = 1.0 - 2.0 * eps;
    float r = 200.0 * sqrt(1.0 - z * z);
    float t = random(TWO_PI );
    x=r*cos(t);
    y=r*sin(t);
    z*=200.0;
  }

  void setValues(float[] values) {
    this.values=values;
  }

  void update(float vx, float vy, float vz) {
    x+=vx;
    y+=vy;
    z+=vz;

    if ((x<-500)||(x>500)||(y<=-500)||(y>500)||(z<=-500)||(z>500)) {
      float eps =random(1.0);
      z = 1.0 - 2.0 * eps;
      float r = 200.0 * sqrt(1.0 - z * z);
      float t = random(TWO_PI);
      x=r*cos(t);
      y=r*sin(t);
      z*=200.0;
      this.setValues(meanValueCoordinates.getValues(x, y, z));
    }
  }

  void draw() {
    
      tint(values[3], values[4], values[5]);
      pushMatrix();
      translate(x, y, z);
      image(sprite, 0, 0);
      popMatrix();
    
  }
}
