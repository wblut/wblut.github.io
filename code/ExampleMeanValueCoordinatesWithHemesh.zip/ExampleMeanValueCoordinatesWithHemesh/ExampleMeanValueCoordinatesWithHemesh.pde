import wblut.core.*;
import wblut.geom.*;
import wblut.hemesh.*;
import wblut.math.*;
import wblut.nurbs.*;
import wblut.processing.*;

int numPoints;
int[] triangles;
float[][] values;
WB_Coord[] vertices;

Wanderer[] wanderers;
WB_Render3D render;
HE_Mesh mesh;
 
void setup() {
  fullScreen(P3D);
  smooth(8);
  noCursor();
  render=new WB_Render3D(this);
  createMesh();
  createWanderers();
}

void createMesh() {
  mesh=new HEC_Icosahedron().setRadius(200.0).create();
  numPoints=12;
  values=new float[numPoints][4];
  for (int i=0; i<numPoints; i++) {
    values[i][0]=random(256.0);
    values[i][1]=random(256.0);
    values[i][2]=random(256.0);
    values[i][3]=random(2.0, 4.0);
  }
  
  triangles=mesh.getTriangles();
  vertices=mesh.getVerticesAsArray();
}

void createWanderers() {
  int numWanderers=4000;
  wanderers=new Wanderer[numWanderers];
  for (int i=0; i<numWanderers; i++) {
    wanderers[i]=new Wanderer();
  }
}

void draw() {
  background(0);
  noLights();
  translate(width/2, height/2);
  rotateY(mouseX*1.0f/width*TWO_PI);
  rotateX(mouseY*1.0f/height*TWO_PI);
  drawMesh();
  drawWanderer();
  drawValues();
  rotateMesh();
}

void drawMesh() {
  strokeWeight(1.0);
  stroke(255);
  render.drawEdges(mesh);
}

void drawWanderer() {
  noStroke();
  for (Wanderer w : wanderers) {
    float[] localValues=WB_MeanValueCoordinates.getValue(w.p,vertices,values,triangles);
    fill(localValues[0], localValues[1], localValues[2]);
    pushMatrix();
    translate(w.p.xf(), w.p.yf(), w.p.zf());
    box(localValues[3]);
    popMatrix();
    w.update();
  }
}

void drawValues() {
  noStroke();
  WB_Coord v;
  for (int i=0; i<numPoints; i++) {
    fill(values[i][0], values[i][1], values[i][2]);
    pushMatrix();
    v=vertices[i];
    translate(v.xf(), v.yf(), v.zf());
    box(3*values[i][3]);
    popMatrix();
  }
}

void rotateMesh(){
 mesh.rotateAboutAxisSelf(radians(0.5),0,0,0,1,1,1);
 vertices=mesh.getVerticesAsArray();
  
}

void mousePressed() {
  for (int i=0; i<numPoints; i++) {
    values[i][0]=random(256.0);
    values[i][1]=random(256.0);
    values[i][2]=random(256.0);
    values[i][3]=random(2.0, 5.0);
  }
}



class Wanderer {
  WB_Point p;
 WB_Vector v;

  Wanderer() {
    p=new WB_Point(random(-1000, 1000),random(-200, 200),random(-600,600)); 
    v=new WB_Vector(-random(0.5, 4.0),0,0);

  }

  void update() {
    
    if(p.getSqLength()<22500){
    p.addMulSelf(0.15,v);
    }else{
      p.addSelf(v);
    }
    if (p.xd()<=-1000) p.addSelf(2000,0,0);
  }
}
