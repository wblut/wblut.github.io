/*
// This is a fast and basic implementation of Jonathan McCabe's multi-scale Turing pattern.
// Check out his paper: http://www.jonathanmccabe.com/Cyclic_Symmetric_Multi-Scale_Turing_Patterns.pdf
// Jason Rampe's blog provides implementation details:
// http://softologyblog.wordpress.com/2011/07/05/multi-scale-turing-patterns/
// Special thanks to Jason for pestering Jonathan about the details ;)
//
// Feel free to use, distribute, change, any_verb this code but please attribute Jonathan for his
// remarkeable algorithm and the beautiful McCabeisms it generates.
//
// Cheers,
// Frederik
//
*/



//checkout the references in the intro, they're a lot better
//than any comments I can come up with
class TuringPattern {
  float[][] activator;
  float[][] inhibitor;
  float[][] variations; 
  int activatorRadiusx;
  int inhibitorRadiusx;
  int activatorRadiusy;
  int inhibitorRadiusy;
  int variationSamplingRadius;
  float stepsize;
  int num;

  TuringPattern(int num, int arx, int irx, int ary, int iry, int vsr, float ss) {
    activator=new float[num][num];
    inhibitor=new float[num][num];
    variations=new float[num][num];
    activatorRadiusx=arx;
    inhibitorRadiusx=irx;
    activatorRadiusy=ary;
    inhibitorRadiusy=iry;
    variationSamplingRadius=vsr;
    stepsize=ss;
    this.num=num;
  }

  void step(float[][] grid, float[][] tmp) {
    diffuse(grid, tmp);
    sampleVariation(tmp);
  }

  void diffuse(float[][] grid, float[][] tmp) {
    blur(grid, activator, tmp, activatorRadiusx, activatorRadiusy);
    blur(grid, inhibitor, tmp, inhibitorRadiusx, inhibitorRadiusy);
  }

  void sampleVariation(float[][] tmp) {
    comp(activator, inhibitor, variations, tmp, variationSamplingRadius);
  }

  void blur(float[][] source, float[][] dest, float[][] tmp, int radiusx, int radiusy) {
    horlineblur(source, tmp, radiusx);
    vrtlineblur(tmp, dest, radiusy);
  }

  void horlineblur (float[][] source, float[][] dest, int radius) {
    for (int j = 0; j < num; ++j) {
      float total = 0;
      for (int di = -radius; di <= radius; di++) {
        total += (di>=0)?source[di][j]:0;
      }
      dest[0][j] = total / (radius * 2 + 1);
      for (int i = 1; i < num; i++) {
        total -= (i - radius - 1>=0)?source[i - radius - 1][j]:0;
        total += (i + radius <num)?source[i + radius][j]:0;
        dest[i][j] = total / (radius * 2 + 1);
      }
    }
  }

  void vrtlineblur (float[][] source, float[][] dest, int radius) {
    for (int i = 0; i < num;i++) {
      float total = 0;
      for (int dj = -radius; dj <= radius; dj++) {
        total += (dj>=0)?source[i][dj]:0;
      }
      dest[i][0] = total / (radius * 2 + 1);
      for (int j = 1; j < num; j++) {
        total -= (j - radius - 1>=0)?source[i][j - radius - 1]:0;
        total += (j + radius <num)?source[i][j + radius]:0;
        dest[i][j] = total / (radius * 2 + 1);
      }
    }
  }

  void comp(float[][] source1, float[][] source2, float[][] dest, float[][] tmp, int radius) {
    horlinecomp(source1, source2, tmp, radius);
    vrtlinecomp(source1, source2, dest, radius);
    for (int i=0;i<num;i++) {
      for (int j=0;j<num;j++) {
        dest[i][j]+=tmp[i][j];
      }
    }
  }

  void horlinecomp (float[][] source1, float[][] source2, float[][] dest, int radius) {
    for (int j = 0; j < num; ++j) {
      float total = 0;
      for (int di = -radius; di <= radius; di++) {
        total += (di>=0)?abs(source1[di][j]-source2[di][j]):0;
      }
      dest[0][j] = total / (radius * 2 + 1);
      for (int i = 1; i < num;i++) {
        total -= (i - radius - 1>=0)?abs(source1[i - radius - 1][j]-source2[i - radius - 1][j]):0;
        total += (i + radius <num)?abs(source1[i + radius][j]-source2[i + radius][j]):0;
        dest[i][j] = total / (radius * 2 + 1);
      }
    }
  }

  void vrtlinecomp (float[][] source1, float[][] source2, float[][] dest, int radius) {
    for (int i = 0; i < num; ++i) {
      float total = 0;
      for (int dj = -radius; dj <= radius; dj++) {
        total += (dj>=0)?abs(source1[i][dj]-source2[i][dj]):0;
      }
      dest[i][0] = total / (radius * 2 + 1);
      for (int j = 1; j < num; j++) {
        total -= (j - radius - 1>=0)?abs(source1[i][j - radius - 1]-source2[i][j - radius - 1]):0;
        total += (j + radius <num)?abs(source1[i][j + radius]-source2[i][j + radius]):0;
        dest[i][j] = total / (radius * 2 + 1);
      }
    }
  }
}

