/*
// This is a fast and basic implementation of Jonathan McCabe's multi-scale Turing pattern.
// Check out his paper: http://www.jonathanmccabe.com/Cyclic_Symmetric_Multi-Scale_Turing_Patterns.pdf
// Jason Rampe's blog provides implementation details:
// http://softologyblog.wordpress.com/2011/07/05/multi-scale-turing-patterns/
// Special thanks to Jason for pestering Jonathan about the details ;)
//
// Feel free to use, distribute, change, any_verb this code but please attribute Jonathan for his
// remarkeable algorithm and the beautiful McCabeisms it generates.
//
// Cheers,
// Frederik
//
*/


float[][] grid;
float[][] tmp;
int num;
int levels;
TuringPattern[] patterns;
int counter;

void setup() {
  size(800, 800); 
  num=400;
  levels=5;
  tmp=new float[num][num];
  patterns=new TuringPattern[levels];
  patterns[0]=new  TuringPattern(num, 100, 200, 100, 200, 1, 0.05);
  patterns[1]=new  TuringPattern(num, 50, 100, 50, 100, 1, 0.04);
  patterns[2]=new  TuringPattern(num, 10, 20, 10, 20, 1, 0.03);
  patterns[3]=new  TuringPattern(num, 5, 10, 5, 10, 1, 0.02);
  patterns[4]=new  TuringPattern(num, 2, 4, 2, 4, 1, 0.01);
  initGrid();
  noStroke();
}

void draw() {
  for (int i=0;i<5;i++) step();
  translate((counter%2)*400, ((counter/2)%2)*400);
  render();
}

void keyPressed() {
  saveFrame("MCB_#####.png");
}

void mouseReleased() {   
  initGrid();
}

void render() {
  for (int i=0;i<num;i++) {
    for (int j=0;j<num;j++) {
      fill(120+120*grid[i][j]);
      rect(i, j, 1, 1);
    }
  }
  counter++;
}

void initGrid() {
  counter=0;
  grid=new float[num][num];
  for (int i=0;i<num;i++) {
    for (int j=0;j<num;j++) {
      grid[i][j]=random(-1, 1);
    }
  }
}

void step() {
  for (int i=0;i<levels;i++) {
    patterns[i].step(grid, tmp);
  }
  updateGrid();
}


//checkout the references in the intro, they're a lot better
//than any comments I can come up with
void updateGrid() {
  float smallest=10;
  float largest=-10;
  for (int i=0;i<num;i++) {
    for (int j=0;j<num;j++) {
      float bestvariation=patterns[0].variations[i][j];
      int bestlevel=0;
      for (int k=1;k<levels;k++) {
        if ((patterns[k].variations[i][j]<bestvariation)) {
          bestlevel=k; 
          bestvariation=patterns[k].variations[i][j];
        }
      }
      if (patterns[bestlevel].activator[i][j]>patterns[bestlevel].inhibitor[i][j]) {
        grid[i][j]+=patterns[bestlevel].stepsize; 
      }
      else {
        grid[i][j]-=patterns[bestlevel].stepsize; 
      }
      largest=max(largest, grid[i][j]);
      smallest=min(smallest, grid[i][j]);
    }
  }
  float range=0.5*(largest-smallest);
  for (int i=0;i<num;i++) {
    for (int j=0;j<num;j++) {
      grid[i][j]=(grid[i][j]-smallest)/range-1;
    }
  }
}


