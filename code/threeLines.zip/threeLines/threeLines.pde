import processing.svg.*;
Spiral S;
void setup() {
  size(1000, 1000, P3D);
  smooth(16);
  noiseDetail(3);
}


void draw() {
  background(255);
  drawDeformedSpiral("spiral001", color(255, 255, 0));
  drawDeformedSpiral("spiral002", color(255, 0, 255));
  drawDeformedSpiral("spiral003", color(0, 255, 255));
  noLoop();
}

void drawDeformedSpiral(String name, color col) {
  pushMatrix();
  beginRecord(SVG, "/SVG/"+name+".svg");
  translate(width/2, height/2);
  S=new Spiral(400.0/102400, 102400, 80);
  noFill();
  stroke(col);
  S.deform();
  S.draw();
  rect(-width/2, -height/2, width, height);
  endRecord();
  popMatrix();
}


class Spiral {
  float[] points;
  Spiral(float r, int num, int s) {
    points=new float[2*num];
    for (int i=0; i<num; i++) {
      points[2*i]=radius(i, r)* cos(i*s*TWO_PI/num);
      points[2*i+1]=radius(i, r)* sin(i*s*TWO_PI/num);
    }
  }

  float radius(int i, float r) {
    return (i+1)*r;
  }

  void draw() {
    beginShape();
    for (int i=0; i<points.length; i+=2) {
      vertex(points[i], points[i+1]);
    }

    endShape(OPEN);
  }

  void deform() {
    noiseSeed((long)random(1000000000));
    for (int i=0; i<points.length; i+=2) {
      float d=dist(points[i], points[i+1], 0, 0);
      float n=20.0*noise((0.0075*points[i]+25), (0.0075*points[i+1]+25))/d;
      points[i]*=1.0+n;
      points[i+1]*=1.0+n;
    }
  }
}
