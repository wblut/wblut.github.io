PShader matcap;
float range;
PGraphics map;
float ax, ay;
PShape shape;
public void setup() {
  size(600, 600, P3D);
  smooth(8);
  map=createGraphics(512, 512, P3D);
  map.smooth(8);
  matcap=loadShader("MatCapFrag.glsl", "MatCapVert.glsl");
  range=0.99;
  matcap.set("range", range);
  drawMap();
  matcap.set("matcap", map);
  shape=createShape();
  shape.beginShape(TRIANGLES);
  for (int i=-100; i<100; i++) {
    for (int j=-100; j<100; j++) {
      shape.vertex(i*2, j*2, bump(i, j));
      shape.vertex((i+1)*2, j*2, bump(i+1, j));
      shape.vertex((i+1)*2, (j+1)*2, bump(i+1, j+1));
      shape.vertex(i*2, j*2, bump(i, j));
      shape.vertex((i+1)*2, (j+1)*2, bump(i+1, j+1));
      shape.vertex(i*2, (j+1)*2, bump(i, j+1));
    }
  }
  shape.endShape();
  shape.disableStyle();
}

void draw() {

  background(25);
  image(map, 10, 10, 64, 64, 0, 0, map.width, map.height);
  translate(width / 2, height / 2);
  rotateY(map(mouseX, 0, width, -PI, PI));
  rotateX(map(mouseY, 0, height, PI, -PI));

  noLights();

  shader(matcap);

  noStroke();
  shape(shape);


  resetShader();
}

void drawMap() {
  map.beginDraw();
  map.ortho();
  map.background(0);
  map.translate(map.width/2, map.height/2);
  map.colorMode(HSB);
  map.noStroke();
  for (int i=10; i>-1; i--) {
    map.fill(i*25, 255, 255);
    map.rect(-256, -256, 512, 12+i*50);
  }
  map.filter(BLUR, 16);
  map.endDraw();
}

float bump(int i, int j) {
  return 40*cos(radians(0.1*i*j));
}
