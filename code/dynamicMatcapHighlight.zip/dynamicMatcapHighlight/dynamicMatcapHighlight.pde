PShader matcap;
float range;
PGraphics map, highlightMap;
float ax, ay;
PShape shape;

public void setup() {
  size(600, 600, P3D);
  smooth(8);
  map=createGraphics(256, 256, P3D);
  map.smooth(8);
  highlightMap=createGraphics(256, 256, P3D);
  highlightMap.smooth(8);
  matcap=loadShader("MatCapFrag.glsl", "MatCapVert.glsl");
  range=0.99;
  matcap.set("range", range);
  shape=createShape();
  shape.beginShape(TRIANGLES);
  for (int i=-100; i<100; i++) {
    for (int j=-100; j<100; j++) {
      shape.vertex(i*2, j*2, bump(i, j));
      shape.vertex((i+1)*2, j*2, bump(i+1, j));
      shape.vertex((i+1)*2, (j+1)*2, bump(i+1, j+1));
      shape.vertex(i*2, j*2, bump(i, j));
      shape.vertex((i+1)*2, (j+1)*2, bump(i+1, j+1));
      shape.vertex(i*2, (j+1)*2, bump(i, j+1));
    }
  }
  shape.endShape();
  shape.disableStyle();
  drawHighlight();
}

void draw() {
  drawMap();
  background(25);
  image(map, 10, 10, 64, 64, 0, 0, map.width, map.height);
  image(highlightMap, 84, 10, 64, 64, 0, 0, map.width, map.height);
  translate(width / 2, height / 2);
  rotateY(ay=map(mouseX, 0, width, -PI, PI));
  rotateX(ax=map(mouseY, 0, height, PI, -PI));
  noLights();
  matcap.set("matcap", map);
  shader(matcap);
  noStroke();
  matcap.set("matcap", map);
  shape(shape);
  blendMode(ADD);
  matcap.set("matcap", highlightMap);
  noStroke();
  shape(shape);
  resetShader();
  blendMode(BLEND);
}

void drawMap() {
  map.beginDraw();
  map.ortho();
  //map.background(0);
  map.translate(map.width/2, map.height/2);
  map.rotateY(ay=map(mouseX, 0, width, -PI, PI));
  map.rotateX(ax=map(mouseY, 0, height, PI, -PI));
  map.pointLight(255, 0, 255, 400*cos(radians(frameCount)), 400*sin(radians(frameCount)), 0);
  map.pointLight(0, 255, 255, 0, 400*cos(0.8*radians(frameCount+65)), 400*sin(0.8*radians(frameCount+65)));
  map.pointLight(255, 255, 0, 400*cos(1.2*radians(frameCount+130)), 0, 400*sin(1.2*radians(frameCount+130)));
  map.noStroke();
  map.sphere(map.width/2);
  map.endDraw();
}

void drawHighlight() {
  highlightMap.beginDraw();
  highlightMap.ortho();
  highlightMap.translate(map.width/2, map.height/2);
  highlightMap.noFill();
  for (int r=0; r<50; r++) {
    highlightMap.stroke(255, 255-5*r);
    highlightMap.circle(0, 0, map.width-r);
  }
  highlightMap.endDraw();
}

float bump(int i, int j) {
  return (60-0.0075*abs(i*j))*cos(radians(0.1*i*j));
}
